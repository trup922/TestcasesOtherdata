const fs = require('fs').promises; // Use fs.promises for async file operations
const path = require('path');

module.exports = class control {

    constructor() {
    }

    async validateInput(obj) {
        /*
            This function first checks the tool pack and the tool selected;
            After which this function would loop through the required (primary) inputs
            to see if any was empty. if empty this function would return false
            and popUp the inputs that needs its value set. 
        */

        let position = null;

        // firstly lets get the tool Pack and tool used, then we can compare the data supplied with the required on 
        //control for tha tools
        Object.keys(obj)[0] == "mission" ? position = 1 : position = 0;
        let tool = Object.keys(obj)[position]

        /*
            We would be limiting the bot feature of this version to process only
            browser or away_Time. This is because the other tools would be on a premium version
        */

            if (tool != "browser" && tool != "away_Time") {
                return { status: false, message: `This tool has been removed from this free version. Use Premium version to access ${tool} tools` };
            }

        // controls 
        let controls = JSON.parse(await this.rtnControls());

        // now we know the tool lets move into getting the requirements and then loop against it
        let required = obj[tool].requirement;

        // now lets compare the ones filled 
        // Check if both objects have the same number of keys and the same keys
        const userKeys = Object.keys(required);

        // lets loop through to find the index of the element tha matches this
        let requiredKeys = null;
        await new Promise ( resolve => {
            controls[tool].forEach( (element, index) => {
            if (element.name == obj[tool]["name"]) {
                requiredKeys = index;
                resolve();
            }
        }) });

        requiredKeys = Object.keys(controls[tool][requiredKeys].requirement);

        if (userKeys.length !== requiredKeys.length || !userKeys.every(key => requiredKeys.includes(key))) {
            return { status: false, message: "The submitted data does not match the required format." };
        }

        // // Check for null or empty values in userSubmitted
        const missingOrEmptyKeys = userKeys.filter(key => obj[tool]["requirement"][key] == null || obj[tool]["requirement"][key] === '');

        if (missingOrEmptyKeys.length > 0) {
            return { status: false, message: `The following data are missing or empty: ${missingOrEmptyKeys.join(', ')}` };
        }

        // check if the data has a url and if it does check if the url is valid
        if (required.url) {
            let urlValidation = this.validate_url(required.url);
            if (urlValidation.status == false) {
                return { status: false, message: urlValidation.message };
            }
        }

        // check if the data has a time and if it does check if the time is valid
        if (required.minimum_Time_On_Page && required.maximum_Time_On_Page) {

            // The time is usally an integer, check if the time is an integer and if it is minimum should never go below 0 and should never be greater than maximum
            // maximum should never be less than 1 and should never be greater than 15

            required.minimum_Time_On_Page = Number(required.minimum_Time_On_Page);
            required.maximum_Time_On_Page = Number(required.maximum_Time_On_Page);

            // if any is Nan return invalid numbers received 

            if(isNaN(required.minimum_Time_On_Page) || isNaN(required.maximum_Time_On_Page)){
                return { status: false, message: "Invalid, you didnt put in a real time in minutes" };
            }


            if (required.minimum_Time_On_Page < 0 || required.minimum_Time_On_Page > 15) {
                return { status: false, message: "The minimum time on page should be between 0 and 15" };
            }

            if (required.maximum_Time_On_Page < 1 || required.maximum_Time_On_Page > 15) {
                return { status: false, message: "The maximum time on page should be between 1 and 15" };
            }

            if (required.minimum_Time_On_Page > required.maximum_Time_On_Page) {
                return { status: false, message: "The minimum time on page should be less than the maximum time on page" };
            }

        }


        return { status: true, message: "All data were filled and validated" };

    }

    validate_url(url) {
        /*
            This function would validate the url provided by the user
            It would check if the url is a valid url and if it is not
            it would return false and popUp the user to enter a valid url
        */
        let urlRegex = new RegExp(/(http(s)?:\/\/.)?(www\.)?[\w-]+\.\w{2,3}(\/\w*)?/);
        if (urlRegex.test(url)) {
            return {status: true, message: "The url is valid"};
        } else {
            return {status: false, message: "The url is invalid"};
        }
    }

    validate_time(min,max) {

    }

    processRequest(req) {
        // this method will analyse the request and reply back with an adequate response

        let data = null;
        return new Promise(async (resolve, reject) => {

            console.log(`  This is our request: `, req)

            if (req.mission == "controls-info") {
                console.log(":Control informations requested")
                data = await this.rtnControls()
                resolve(data)
            }
            if (req.mission == "validate-input") {
                console.log(":Informations received for validation");
                data = await this.validateInput(req);
                resolve(data)
            }

            reject({ status: "failed", error:" You did not specify an existing command" });
        });
    };

    async rtnControls() {

        const filePath = path.join(__dirname, 'control.json');
        return (await fs.readFile(filePath, 'utf8'));

    }


}
