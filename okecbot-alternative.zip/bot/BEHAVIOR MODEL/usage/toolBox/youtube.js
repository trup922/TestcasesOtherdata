class youtube{

    constructor(){

    }


}

module.exports = new youtube();