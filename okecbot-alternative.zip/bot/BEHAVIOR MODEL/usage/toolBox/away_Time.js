const actions = require('../../actions')
//module.exports = 
module.exports = class away_Time extends actions{

    /*
        As the name suggests, this class is used to interact with the browser.
    */

    constructor(personality_Object){
        //we have a section for the personality object, this is where we would store the personality of the bot.
        super(personality_Object);
        this.personality_Object = personality_Object;

    }

    async log_off(primary_Action_To_Execute,secondary_Action_To_Execute){

        /*
            This method would make the bot log off. By loggin off, we mean the bot would visit the log off page.
            The log off page is the page that the bot would visit when it is not doing anything.
            This will be our custom page ( okecbot ) custom page.
                KEY ONE:: => A string containing the minimum_Time_On_Page.
                KEY TWO:: => A string containing the maximum_Time_On_Page.

        */

                try{
                    
                    await this.directVisit("https://okecbot.com/log_off");
                    let time_On_Page = await this.time_On_Page_From_Range(primary_Action_To_Execute.minimum_Time_On_Page,primary_Action_To_Execute.maximum_Time_On_Page);
                    this.personality_Object.set_Memo_And_Update_BotEngine("log",`bot: ${this.personality_Object.botName} visited the log off page to wait and has decided to spend ${time_On_Page} seconds on the page.`);
                    await this.pick_Interaction_with_page(time_On_Page)
                    return `${this.personality_Object.botName} Is has whiled away time at the log off page. Its now time to do something else`

                }catch(e){
                    return `${this.personality_Object.botName} couldnt while away time at the log off page. something terrible happened`
                }

    }



}
