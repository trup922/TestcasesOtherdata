const actions = require('../../actions')
//module.exports = 
module.exports = class browser extends actions{

    /*
        As the name suggests, this class is used to interact with the browser.
    */

    constructor(personality_Object){
        //we have a section for the personality object, this is where we would store the personality of the bot.
        super(personality_Object);

        this.personality_Object = personality_Object;

    }

    async visit_website(primary_Action_To_Execute,secondary_Action_To_Execute){

        /*
            This method would be able to visit a website, move around and interact with it.
            The primary_Action_To_Execute parameter is the first action that the bot will execute.
            It has 3 mandatory keys that must be provided (inside the primary action object):
                KEY ONE:: => url: The url of the website to visit.
                KEY TWO:: => A string containing the minimum_Time_On_Page.
                KEY THREE:: => A string containing the maximum_Time_On_Page.

            The secondary_Action_To_Execute parameter is the second action that the bot will execute.
            This action is an xpath to click on.
            It has 3 mandatory keys that must be provided (inside the primary action object):
                KEY ONE:: => An xpath: The url of the website to visit.
                KEY TWO:: => A string containing the minimum_Time_On_Page.
                KEY THREE:: => A string containing the maximum_Time_On_Page.
        */

                try{
                    
                    await this.directVisit(primary_Action_To_Execute.url);
                    let time_On_Page = await this.time_On_Page_From_Range(primary_Action_To_Execute.minimum_Time_On_Page,primary_Action_To_Execute.maximum_Time_On_Page);
                    this.personality_Object.set_Memo_And_Update_BotEngine("log",` bot: ${this.personality_Object.botName} visited ${primary_Action_To_Execute.url} and its now going to interract with the page for ${time_On_Page} seconds`)
                    await this.pick_Interaction_with_page(time_On_Page)
                    this.personality_Object.set_Memo_And_Update_BotEngine("log",` bot: ${this.personality_Object.botName}  excuted the primary action successfully, moving to secondary now, OVER and OUT`);

                    try{

                        await  this.webPage.waitForSelector(secondary_Action_To_Execute["click_location"].xpath)

                        await this.click_on_element(secondary_Action_To_Execute["click_location"].xpath);

                        let time_On_Page = await this.time_On_Page_From_Range(secondary_Action_To_Execute["click_location"].minimum_Time_On_Page,secondary_Action_To_Execute["click_location"].maximum_Time_On_Page);
                        this.personality_Object.set_Memo_And_Update_BotEngine("log",` bot: ${this.personality_Object.botName} clicked ${this.personality_Object.xpath} selector and will now interract with the page for ${time_On_Page} seconds`)
                        await this.pick_Interaction_with_page(time_On_Page)
                        this.personality_Object.set_Memo_And_Update_BotEngine("log",` bot: ${this.personality_Object.botName}  excuted the primary action successfully, we would resolve now so other actions can be executed. OVER AND OUT`);

                        return ` bot: ${this.personality_Object.botName} executed the primary and secondary action successfully, we would resolve now so other actions can be executed. OVER AND OUT`

                    }catch(e){
                       return ` bot: ${this.personality_Object.botName} couldnt execute the secondary action, we would abort this mission.`
                    }


                }catch(e){
                    return ` bot: ${this.personality_Object.botName} couldnt execute the Primary action, we would abort this mission. ${e} `
                }

    }



}
