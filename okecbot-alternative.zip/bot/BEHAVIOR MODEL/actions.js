// This component would focused on  human activities 

const { createCursor } = require("ghost-cursor");
module.exports = class HumanBehavior {

    constructor(personality_Object) {
        this.webPage = personality_Object.chromeBrowserPage;
        this.cursor = createCursor(this.webPage)

        this.botName_instance = personality_Object;
    }

    async directVisit(url) {

        await this.installMouseHelper();

        // visit a website directly
        await this.webPage.goto(url, { waitUntil: 'domcontentloaded' })


    }

    async installMouseHelper() {
        const iconUrl = 'http://localhost:3000/images/okecbot-bounce.png';

        await this.webPage.evaluateOnNewDocument((iconUrl) => {
            // Install mouse helper only for the top-level frame.
            if (window !== window.parent)
                return;

            window.addEventListener('DOMContentLoaded', () => {
                const box = document.createElement('puppeteer-mouse-pointer');
                const styleElement = document.createElement('style');
                styleElement.innerHTML = `
              puppeteer-mouse-pointer {
                pointer-events: none;
                position: absolute;
                top: 0;
                z-index: 10000;
                left: 0;
                width: 40px;
                height: 40px;
                background: url('${iconUrl}');
                background-size: contain;
                border: none;
                margin: 0;
                padding: 0;
                transition: background .2s;
              }
              puppeteer-mouse-pointer.button-1 {
                transition: none;
                background: url('${iconUrl}');
                background-size: contain;
              }
              puppeteer-mouse-pointer.button-2 {
                transition: none;
              }
              puppeteer-mouse-pointer.button-3 {
                transition: none;
              }
              puppeteer-mouse-pointer.button-4 {
                transition: none;
              }
              puppeteer-mouse-pointer.button-5 {
                transition: none;
              }
            `;
                document.head.appendChild(styleElement);
                document.body.appendChild(box);
                document.addEventListener('mousemove', event => {
                    box.style.left = event.pageX + 'px';
                    box.style.top = event.pageY + 'px';
                    updateButtons(event.buttons);
                }, true);
                document.addEventListener('mousedown', event => {
                    updateButtons(event.buttons);
                    box.classList.add('button-' + event.which);
                }, true);
                document.addEventListener('mouseup', event => {
                    updateButtons(event.buttons);
                    box.classList.remove('button-' + event.which);
                }, true);

                function updateButtons(buttons) {
                    for (let i = 0; i < 5; i++)
                        box.classList.toggle('button-' + i, buttons & (1 << i));
                }
            }, false);
        }, iconUrl);
    }

    // Click an element given its selector
    async click_on_element(selector) {
        const element = await this.webPage.$(selector);
        await this.cursor.click(selector);
        await this.sleep(this.getRandomInt(5000, 10000));
        
    }

    // Fill an input field with specified text
    async fillInput(selector, text) {
        await this.webPage.type(selector, text);
    }

    // Hover over an element given its selector
    async hoverElement(selector) {
        const element = await this.webPage.$(selector);
        if (element) {
            await element.hover();
        }
    }

    // Take a screenshot of the current web page view
    async takeScreenshot(filename = 'screenshot.png') {
        await this.webPage.screenshot({ path: filename });
    }

    // Navigate back to the previous page
    async goBack() {
        await this.webPage.goBack();
    }

    // Navigate forward (if there was a previous backward navigation)
    async goForward() {
        await this.webPage.goForward();
    }

    // Reload the current page
    async reloadPage() {
        await this.webPage.reload();
    }

    // Close the current tab or page
    async closeTab() {
        await this.webPage.close();
    }

    time_On_Page_From_Range(minimum_Time_On_Page, maximum_Time_On_Page) {
        /*
            This method would receive a minimum and maximum time on page  but it is in minutes.
            We would first convert it to miliseconds.
            Then we would generate a random number between the minimum and maximum time from the miliseconds converted.
            Then we would return the random number.
        */

        let minimum_Time_On_Page_In_Seconds = minimum_Time_On_Page * 60000
        let maximum_Time_On_Page_In_Seconds = maximum_Time_On_Page * 60000;
        let random_Number_Between_Minimum_And_Maximum = this.getRandomInt(minimum_Time_On_Page_In_Seconds, maximum_Time_On_Page_In_Seconds);
        return random_Number_Between_Minimum_And_Maximum;

    }

    async interact_with_Page_Inconcern(time_On_Page) {
        return new Promise(async (resolve) => {

            /*
                Using the time_On_Page parameter, this method interact with the page at random locations after a while it moves
                into a direction a bit and then it randomly moves the curor to another location along with a new scroll position.
            */
            let maxHeight = await this.webPage.evaluate(() => document.documentElement.scrollHeight);
            let currentHeight = 0;
            const startTime = Date.now();

            // Initialize mouse position
            let currentMousePosition = { x: 0, y: 0 };

            // Continue the loop until the specified time on page has passed
            while (Date.now() - startTime < time_On_Page) {
                // Get a random scroll length between 100 and 5000
                let scrollLength = this.getRandomInt(100, 5000);

                // Randomly decide the direction of the scroll (up or down)
                let direction = Math.random() < 0.5 ? -1 : 1;

                // Update the current height based on the scroll length and direction
                currentHeight += scrollLength * direction;

                // If the current height exceeds the maximum height of the page, set it to the maximum height
                if (currentHeight > maxHeight) {
                    currentHeight = maxHeight;
                }
                // If the current height is less than 0, set it to 0
                else if (currentHeight < 0) {
                    currentHeight = 0;
                }

                // Scroll to the current height
                await this.webPage.evaluate(async (newHeight) => {
                    window.scrollTo(0, newHeight);
                }, currentHeight);

                // Get the width and height of the viewport
                let viewportWidth = await this.webPage.evaluate(() => document.documentElement.clientWidth);
                let viewportHeight = await this.webPage.evaluate(() => document.documentElement.clientHeight);

                // Get a random position within the viewport for the mouse to move to
                let randomX = this.getRandomInt(0, viewportWidth);
                let randomY = this.getRandomInt(0, viewportHeight);

                // Calculate the distance the mouse should move in each step
                let distanceX = (randomX - currentMousePosition.x) / 100;
                let distanceY = (randomY - currentMousePosition.y) / 100;

                // Move the mouse in 100 small steps to create a smooth movement effect
                for (let i = 0; i < 100; i++) {
                    let newX = currentMousePosition.x + distanceX * i;
                    let newY = currentMousePosition.y + distanceY * i;
                    await this.webPage.mouse.move(newX, newY);
                    await this.sleep(10); // Wait a bit between each movement
                }

                // Update the current mouse position to the new position
                currentMousePosition = { x: randomX, y: randomY };

                // Wait for a random delay between 500 and 3000 milliseconds
                let delay = this.getRandomInt(500, 3000);
                await this.sleep(delay);
            }

            resolve();
        });
    }

    async pick_Interaction_with_page(time_On_Page) {
        /*
            This method would randomly pick one of the interraction with the page
            This interraction would be concerned or inconcerned.
            This is to aid the bot to behave like a human.
        */

        let random_Number_Between_1_And_2 = this.getRandomInt(1, 2);
        if (random_Number_Between_1_And_2 == 1) {
            console.log("I am interacting inconcern")
            await this.interact_with_Page_Inconcern(time_On_Page);
        } else {
            console.log("I am concerned")
            await this.interact_with_Page_Concern(time_On_Page);
        }
    }


    async interact_with_Page_Concern(time_On_Page) {
        return new Promise(async (resolve) => {
            let maxHeight = await this.webPage.evaluate(() => document.documentElement.scrollHeight);
            let currentHeight = 0;
            const startTime = Date.now();

            // Initialize mouse position
            let currentMousePosition = { x: 0, y: 0 };

            while (Date.now() - startTime < time_On_Page) {
                let scrollLength = this.getRandomInt(100, 5000);
                let direction = Math.random() < 0.5 ? -1 : 1;
                currentHeight += scrollLength * direction;

                if (currentHeight > maxHeight) {
                    currentHeight = maxHeight;
                } else if (currentHeight < 0) {
                    currentHeight = 0;
                }

                await this.webPage.evaluate(async (newHeight) => {
                    window.scrollTo(0, newHeight);
                }, currentHeight);

                let viewportWidth = await this.webPage.evaluate(() => document.documentElement.clientWidth);
                let viewportHeight = await this.webPage.evaluate(() => document.documentElement.clientHeight);

                // Randomly select a mouse movement pattern
                let pattern = this.getRandomInt(1, 8);
                switch (pattern) {
                    /*
                        to beat bot detection systems, keep in mind that these systems often look for
                         patterns and repetition, so using a variety of patterns and introducing more 
                         randomness could potentially make the bot seem more human-like. However, 
                         sophisticated bot detection systems may use advanced techniques like machine 
                         learning to distinguish between human and bot behavior, 
                        and these might not be easily fooled by simple cursor movement patterns.
                    */
                    case 1: // Top to bottom
                        for (let i = 0; i <= 100; i++) {
                            let newX = currentMousePosition.x;
                            let newY = (viewportHeight / 4 / 100) * i; // Adjusted this line
                            await this.webPage.mouse.move(newX, newY);
                            await this.sleep(10);
                        }
                        break;
                    case 2: // Left to right
                        for (let i = 0; i <= 100; i++) {
                            let newX = (viewportWidth / 4 / 100) * i; // Adjusted this line
                            let newY = currentMousePosition.y;
                            await this.webPage.mouse.move(newX, newY);
                            await this.sleep(10);
                        }
                        break;
                    case 3: // Diagonal
                        for (let i = 0; i <= 100; i++) {
                            let newX = (viewportWidth / 4 / 100) * i; // Adjusted this line
                            let newY = (viewportHeight / 4 / 100) * i; // Adjusted this line
                            await this.webPage.mouse.move(newX, newY);
                            await this.sleep(10);
                        }
                        break;
                    case 4: // Diagonal reversed
                        for (let i = 100; i >= 0; i--) {
                            let newX = (viewportWidth / 4 / 100) * i; // Adjusted this line
                            let newY = (viewportHeight / 4 / 100) * i; // Adjusted this line
                            await this.webPage.mouse.move(newX, newY);
                            await this.sleep(10);
                        }
                    case 5: // Zigzag
                        for (let i = 0; i <= 100; i++) {
                            let newX = (viewportWidth / 4 / 100) * i;
                            let newY = (viewportHeight / 4 / 100) * (i % 2 === 0 ? i : 100 - i);
                            await this.webPage.mouse.move(newX, newY);
                            await this.sleep(10);
                        }
                        break;
                    case 6: // Circular
                        let radius = Math.min(viewportWidth, viewportHeight) / 8;
                        for (let i = 0; i <= 100; i++) {
                            let angle = 2 * Math.PI * i / 100;
                            let newX = currentMousePosition.x + radius * Math.cos(angle);
                            let newY = currentMousePosition.y + radius * Math.sin(angle);
                            await this.webPage.mouse.move(newX, newY);
                            await this.sleep(10);
                        }
                    case 7: // Random walk
                        let steps = 100;
                        for (let i = 0; i <= steps; i++) {
                            let direction = Math.random() * 2 * Math.PI;
                            let distance = Math.random() * viewportWidth / 4 / steps;
                            let newX = currentMousePosition.x + distance * Math.cos(direction);
                            let newY = currentMousePosition.y + distance * Math.sin(direction);
                            await this.webPage.mouse.move(newX, newY);
                            await this.sleep(10);
                        }
                        break;
                    case 8: // Spiral
                        let rotations = 5;
                        for (let i = 0; i <= 100; i++) {
                            let angle = 2 * Math.PI * rotations * i / 100;
                            let radius = (viewportWidth / 4 / 100) * i;
                            let newX = currentMousePosition.x + radius * Math.cos(angle);
                            let newY = currentMousePosition.y + radius * Math.sin(angle);
                            await this.webPage.mouse.move(newX, newY);
                            await this.sleep(10);
                        }
                        break;
                }

                // Update current mouse position
                currentMousePosition = { x: viewportWidth, y: viewportHeight };

                let delay = this.getRandomInt(500, 3000);
                await this.sleep(delay);

                if (Math.random() < 0.2) {
                    let scrollUpLength = this.getRandomInt(100, 500);
                    currentHeight -= scrollUpLength;
                    if (currentHeight < 0) {
                        currentHeight = 0;
                    }
                    await this.webPage.evaluate(async (newHeight) => {
                        window.scrollTo(0, newHeight);
                    }, currentHeight);
                }
            }

            resolve();
        });
    }

    // Helper function: Get random number between min and max (inclusive)
    getRandomInt(min, max) {
        min = Math.ceil(min);
        max = Math.floor(max);
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    // Helper function: Sleep for a given duration
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async humanTyping(elementSelector, textToType) {
        const inputElement = await this.webPage.$(elementSelector);
        for (let char of textToType) {
            await inputElement.type(char, { delay: this.getRandomInt(50, 150) });
        }
    }

    async generateTxt(channelURL, text_to_generate) {
        // Step 1: Generate the comment using OpenAI API
        const OPENAI_API_URL = 'https://api.openai.com/v1/engines/davinci/completions';
        const API_KEY = 'YOUR_OPENAI_API_KEY';

        const promptText = ` "${text_to_generate}"`;

        const response = await axios.post(OPENAI_API_URL, {
            prompt: promptText,
            max_tokens: 150
        }, {
            headers: {
                'Authorization': `Bearer ${API_KEY}`,
                'Content-Type': 'application/json'
            }
        });

        const comment = response.data.choices[0].text.trim();


    }



}