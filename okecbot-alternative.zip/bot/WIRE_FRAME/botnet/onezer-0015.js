
const WebSocket = require('ws');
const person = require("../../HUMAN MODEL/personality.js");
const behavior = require("../../BEHAVIOR MODEL/actions");
const path = require('path');

function getScriptName() {
    // This function returns the name of the script that is currently running
    const fileNameWithExtension = path.basename(__filename);
    const fileNameWithoutExtension = path.parse(fileNameWithExtension).name;
    return fileNameWithoutExtension;
}

var botName = getScriptName();

const modeled =  {"Account":{"fullname":"onezer-0015","OKECBOT_Api_key":"chalz-api"},"Cookie":[],"LocalStorage":[],"CookieType":"Idle","Memo":{"about":"I am a male from a timezone of America\/New_York","device":"I am currently using the Tecno Spark 5,Tecno Phantom 9,Tecno Spark 5,Samsung Galaxy S9,Tecno Camon 12,iPhone 13 Pro,iPhone 12 Pro,iPhone 7 Plus,iPhone 8 Plus,iPhone 8 Plus,iPhone 13 Pro Max,iPhone 12,Mac OS X 10.6 Snow Leopard 1280 x 800,Mac OS X 10.9 Mavericks 2880 x 1800,Mac OS X 10.6 Snow Leopard 1280 x 800,macOS 10.14 Mojave 4096 x 2304,Mac OS X 10.7 Lion 1440 x 900,macOS 11 Big Sur 2560 x 1600,Windows XP 800 x 600,Windows 7 1366 x 768,Windows 10 1366 x 768,Windows 11 1920 x 1080,Windows 8.1 1366 x 768,Windows 10 1366 x 768,Windows 8 1920 x 1080,Windows 7 1366 x 768"},"Device":{"resolution":{"width":1280,"height":800},"userAgent":"Mozilla\/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/49.0.2623.112 Safari\/537.36","isMobile":true,"hasTouch":true,"timeZone":"America\/New_York","deviceName":"Mac OS X 10.6 Snow Leopard 1280 x 800"},"Location":{"proxyType":"http","proxyServer":"http:\/\/#proxyServer:undefined","proxyUsername":"hederticliaG0v","proxyPassword":"kbn41wIGy28sH0K3"}};

async function runBot() { console.log("onezer-0015 is running...")
    const okecbot = new person(modeled);

    okecbot.showBrowser(false);
    await okecbot.startLife();

    const ws = new WebSocket('ws://localhost:3002');

    ws.on('open', function open() {

        /*         
        Pass the reference of this opened web socket connection to the personality Object that was initiated above.
        ~ The personality method would use this opened socket to a process and exchange json/data with the botEngine
         */

        okecbot.establish_BotFamily_Socket(ws,onezer,onezer-0015);

        ws.on('error', function error(err) {
            console.error('WebSocket error:', err);
        });

        ws.on('close', function close() {
            console.log('onezer-0015 is disconnected from the botEngine');
        });
    });

    await okecbot.execute_Executable({
    "away_Time": {
        "name": "away_time",
        "requirement": {
            "minimum_Time_On_Page": "15",
            "maximum_Time_On_Page": "20"
        }
    }
}).then((response) => {
       process.exit();
    })


}

runBot();

        
        