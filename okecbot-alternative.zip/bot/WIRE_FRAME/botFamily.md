# botFamily

`botFamily` is a class that manages a diverse set of bot personalities and tasks, providing detailed control over bot behavior and actions. It parses and utilizes data to manage the execution of tasks across different device brands and personalities.

## Configuration

The `botFamily` configuration includes the following:

- **botFamily_Name**: A simple identifier for the bot family, used to differentiate between different bot families within your system.

- **botFamily_Executables**: A mapping of executable actions that bots can perform. Each executable has its own unique ID and contains detailed configurations like browser actions or away times.

- **botFamily_Device_Brands**: Arrays of stringified JSON objects for each device brand (iPhone, Android, Mac, and Windows). Each object includes details about the account, device specifications, and location settings.

- **botFamily_Device_Brand_Execute_Limit**: Specifies the maximum number of executions allowed per device brand.

- **botFamily_Minimum_Active_Device_Brand** and **botFamily_Maximum_Active_Device_Brand**: Define the bounds for how many devices of each brand should be active at any given time.

- **botFamily_Repeat_Executable**: A boolean flag indicating whether executables can be repeated.

## Methods

The `botFamily` class includes the following methods:

- **is_Executable**: Verifies if the bot family configuration meets all the necessary conditions to start executing tasks.

- **random_Personality_and_Executable**: Selects a random subset of devices (personalities) for a given device brand and pairs them with a random executable.

- **launch_Personality_and_Executable**: Initiates the execution process once a device and executable are selected.

These methods manage and utilize the configuration data to ensure that bots are effectively deployed and managed according to your specifications.