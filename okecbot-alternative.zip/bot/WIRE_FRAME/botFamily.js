const fs = require('fs');
const { exec } = require('child_process');
const path = require('path');
module.exports = class botFamily {
    
/*
    USE CASE DESCRIPTION:

    Goal of this class:
    The BotFamily class is used to launch puppeteer scripts with specific configurations (personalities). This launched puppeteer scripts would excute an activity that was randomly picked at its creation. 
    The mission of a botFamily object is to keep creating and running puppeteer scripts made with the device brand personalities until all device brand has reached it's limit of execution. 

    Intiaition of this class:
    This class would be initiated with a botFamily_data object. The botFamily_data object would contain all the needed informations to execute the botFamily's mission.

    Activity and process of the botFamily:
    -   The botFamily object would be first instantiated by the botAi class using arguments received as "botFamily_data".
    -   The botFamily object would not be added to the botAi list of bot Families unless the mission of the botFamily is executeable. 
    -   To know if a botFamily has a valid mission that can be executed, the botAi calls the is_Executable method of the botFamily object.
    -   If the botFamily is executable, the botAi would add the botFamily to the list of bot Families.
    -   The botAi calls the uphold_Execution method of the botFamily object to keep the botFamily executing until the mission has been completed.

    How Mission is started and completed:
       # Generating the "execution_log" object:
        -   When the uphold_Execution method is called for the first time, there wont be an "execution_log" available, so, this botFamily object would generate a property called "execution_log". 
            The "execution_log" property would be an object with lots of nested objects. 
            Firstly the "execution_log" object would have 4 keys representing the device brands(iphone,android,windows,mac). 
            Secondly, the value of each key (representing a device brand) would be another object
            Thirdly, inside object (value of a device brand key) would be keys representing a device (stringified objects A.K.A personalities)
            Fourthly, The value to a personality (keys) would be a copy of the this.executable property.
        -   When this "execution_log" object has been generated, the uphold_Execution method can then proceed. to call the mission_Completed method to check if the mission has been completed.
        -   The mission_Completed method would check every device brand to see if it has completed its mission.
        -   If the mission has not been completed, It means one or more device brand has not executed to there limit
        -   If a device brand has not reached its limit it means we might need to spawn devices and have them execute an executable so as to get closer to there execution (limit).
        -   In other to do this we would follow the steps below:

       # Spawning devices:
        -   The spawn_device method receives an argument (string ) representing a device brand.
        -   The spawn_device would first check if the device brand has any strigified personality left to launch. It would do the checking by calling the device_Spawn_Range method. 
            If the returned value from device_Spawn_Range is 0, The spawn_device would return null and there would be no spawning of newer device. This is because we have up to the minimum number of active devices. 
            If the returned value is greater than 0, we would call the random_Personality_and_Executable method and give it 2 arguments. argument one is the device brand and argument two is the number of strigified personality from the device brand to be picked at random.
            The random_Personality_and_Executable method would return an array of objects. Each item in the array would be an object who's key is the stringified personality and the value of the key is a randomly picked executable.
        _   The spawn_device would then call launch_Personality_and_Executable method for each item in the array returned by random_Personality_and_Executable with 3 arguments. 
                -The first argument is a stringified personality: A stringified personality in this context refers to a key of an object(item) in the array returned by the random_Personality_and_Executable method.
                -The second argument is the executable: The executable is the value of the key of the object(item) in the array returned by the random_Personality_and_Executable method.
                -The third argument is the device brand. The device brand is the string that was passed to the spawn_device method.
            We would call the launch_Personality_and_Executable method for each item in the array returned by random_Personality_and_Executable method. we would do this with an await Promise.allSettled method.
            This would enable us to wait for all the devices to be done before we continue the execution of the uphold_Execution method.

        # Launching a personality and executable:
        -   The launch_Personality_and_Executable method would be called by the spawn_device method for each item in the array returned by the random_Personality_and_Executable method.
        -   The launch_Personality_and_Executable method when called, would first check the values(objects) in this.active_Devices using the device_brand as the key (this.active_Devices[device_brand]). 
            If the received stringified personality is found as a key in the value(object) of this.active_Devices[device_brand] that means the personality object has already been launched and it is currently executing an executable.
            If the received stringified personality  is not found in the value(object) of this.active_Devices[device_brand], it means the personality object is not currently launched at the moment.
            Since the personality object is not currently launched, we would create a new JavaScript file using a template and the received stringified personality received. The file is saved in a specific folder designated for bots. 
            The name to save the file  is extracted from parsing the stringified personality object into a proper object and access the Account.fullName property.
            Once the file has been created, we would run the file as a child process using the node.js child_process module.
            The child process would be created using the exec method of the child_process module. The exec method would take in the path to the file to be run as a child process and a callback function.
            The callback function would be called when the child process has been created. The callback function would check if the child process has an error and if it does, it would log the error to the console and write the error to a log file.
            If the child process has no error, it would log the stdout and stderr to the console and write the stdout and stderr to a log file.
            The launch_Personality_and_Executable method would also call the update_Active_list method with 2 arguments. The first argument is the string "activate" and the second argument is the device brand.
            The update_Active_list method would be used to update the active devices in a device brand.
        -   The launch_Personality_and_Executable method would return a string stating "running" if the personality object has been launched and is currently executing an executable.
        
        # Updating the active list:
        -   The update_Active_list method would be used to update active devices in a device brand.
        -   The update_Active_list method would take in 3 arguments. The first argument is a string representing the action to be taken. The action could be either "activate" or "de-activate".
            The second argument is a string representing the device brand. The third argument is a stringified personality object.
        -   If the action is "activate", the update_Active_list method would add the personality to the array of the (active) device brand if it's not already present.
        -   If the action is "de-activate", the update_Active_list method would remove the personality from the array of the (active) device brand if it's present.
        -   The update_Active_list method would log the action taken to the console.










   Illustration of botFamily_data object:
    {
            botFamily_Name: "example: audiomack"}
            
                        }
                            OR
                            
                        {
            botFamily_Name: "example: audiomack"
            botFamily_Executables:  { "activity1" : {object}, "activity2": {object} },
            botFamily_Device_Brands: {
                iphone: ["audiomack-0001", "audiomack-0002", "audiomack-0003"],
                android: ["audiomack-0005", "audiomack-0006", "audiomack-0007"],
                windows: ["audiomack-0031", "audiomack-0032", "audiomack-0043"],
                mac: ["audiomack-0081", "audiomack-0082", "audiomack-0083"],
            }
            botFamily_Device_Brand_Execute_Limit:{
                iphone: 10000,
                android: 30000,
                windows: 15000,
                mac: 12000,
            }
            botFamily_Minimum_Active_Device_Brand:{
                iphone: 5,
                android: 5,
                windows: 5,
                mac: 5,
            }
            botFamily_Maximum_Active_Device_Brand:{
                iphone: 10,
                android: 10,
                windows: 10,
                mac: 10,
            }
        
    }

    Explanation of the data:
    -   department: This is the action to be taken. It could be either "activate" or "de-activate"
    -   compliment_Data: This is an object that contains all the needed informations to execute the users request. It is an object with the following properties:
        -   botFamily_Name: Value expected is a string. The string is used to name the object instance of the botFamily that would be created.
        -   botFamily_Executables: Value expected is an object. The object keys are used to name a specific executeable. The value of each key is an object to be executed by a device in the family
        -   botFamily_Device_Brands: Value expected is an object. The object contains keys representing a device brand like android, iphone etc.
            the value of each key (device brand) is an array and the items of this array are stringified objects. This stringified object are known to us the developers of this project as "personalities or personality object". 
            By persoanlities, we mean, when the personality stringified object is json parsed it becomes an object with keys representing a browser cookie,view port, user agent and a specific puppeteer configurations to launch the puppeteer as a specific device model.
        
        -   botFamily_Device_Brand_Execute_Limit: Value expected is an objects. The keys of the object represent a device brand like iphone,samsung,windows etc.
            The value of the keys (device brand) is a number (integer). This number represents the maximum number of times a device brand can execute a task at a given time.
        -   botFamily_Minimum_Active_Device_Brand: Value expected is an objects. The keys represent the minimum number of a platicular device brand (device brand personalities) that should be active at a given time.
        -   botFamily_Maximum_Active_Device_Brand: Value expected is an objects. The keys represent the maximum number of a platicular device brand (device brand personalities) that should be active at a given time.


    */

    constructor(botFamily_data) {
        /*
            This constructor would be used to create a botFamily object.
            The botFamily object would be used to house a botFamily, its running processes and its data.
        */

        this.name = botFamily_data.botFamily_Name;
        this.executable = botFamily_data.botFamily_Executables;
        this.devices = botFamily_data.botFamily_Device_Brands;
        this.execution_Limit = botFamily_data.botFamily_Device_Brand_Execute_Limit;
        this.minimum_Active_Device_Brand = botFamily_data.botFamily_Minimum_Active_Device_Brand;
        this.maximum_Active_Device_Brand = botFamily_data.botFamily_Maximum_Active_Device_Brand;
        this.repeat_Executable = botFamily_data.botFamily_Repeat_Executable;



        this.active_Devices = {
            "iphone": [],
            "android": [],
            "windows": [],
            "mac": []
        };

        this.execute_count = {
            "iphone": 0,
            "android": 0,
            "windows": 0,
            "mac": 0
        };

    }

    sleep(ms) {
        // Majority of our activities such as pinging a bot or waiting for a process requires a delay.
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    is_Executable() {

        /*
            This method would be used to check if the botFamily is executable.
            If the botFamily is executable, it would return true.

        */

        if (Object.keys(this.executable).length < 1) return { status: "failed", body: "No executable found in the botFamily" }
        if (this.devices.iphone.length < 1 && this.execution_Limit.iphone > 0) return { status: "failed", body: "No iphone device found in the botFamily" }
        if (this.devices.android.length < 1 && this.execution_Limit.android > 0) return { status: "failed", body: "No android device found in the botFamily" }
        if (this.devices.windows.length < 1 && this.execution_Limit.windows > 0) return { status: "failed", body: "No windows device found in the botFamily" }
        if (this.devices.mac.length < 1 && this.execution_Limit.mac > 0) return { status: "failed", body: "No mac device found in the botFamily" }

        if (this.minimum_Active_Device_Brand.iphone > this.maximum_Active_Device_Brand.iphone) return { status: "failed", body: "The minimum number of active iphone device is greater than the maximum number of active iphone device" }
        if (this.minimum_Active_Device_Brand.android > this.maximum_Active_Device_Brand.android) return { status: "failed", body: "The minimum number of active android device is greater than the maximum number of active android device" }
        if (this.minimum_Active_Device_Brand.windows > this.maximum_Active_Device_Brand.windows) return { status: "failed", body: "The minimum number of active windows device is greater than the maximum number of active windows device" }
        if (this.minimum_Active_Device_Brand.mac > this.maximum_Active_Device_Brand.mac) return { status: "failed", body: "The minimum number of active mac device is greater than the maximum number of active mac device" }

        if (this.minimum_Active_Device_Brand.iphone < 0) return { status: "failed", body: "The minimum number of active iphone device is less than 0" }
        if (this.minimum_Active_Device_Brand.android < 0) return { status: "failed", body: "The minimum number of active android device is less than 0" }
        if (this.minimum_Active_Device_Brand.windows < 0) return { status: "failed", body: "The minimum number of active windows device is less than 0" }
        if (this.minimum_Active_Device_Brand.mac < 0) return { status: "failed", body: "The minimum number of active mac device is less than 0" }

        if (this.maximum_Active_Device_Brand.iphone < 0) return { status: "failed", body: "The maximum number of active iphone device is less than 0" }
        if (this.maximum_Active_Device_Brand.android < 0) return { status: "failed", body: "The maximum number of active android device is less than 0" }
        if (this.maximum_Active_Device_Brand.windows < 0) return { status: "failed", body: "The maximum number of active windows device is less than 0" }
        if (this.maximum_Active_Device_Brand.mac < 0) return { status: "failed", body: "The maximum number of active mac device is less than 0" }

        if (this.execution_Limit.iphone < 0) return { status: "failed", body: "The iphone device execution limit is less than 0" }
        if (this.execution_Limit.android < 0) return { status: "failed", body: "The android device execution limit is less than 0" }
        if (this.execution_Limit.windows < 0) return { status: "failed", body: "The windows device execution limit is less than 0" }
        if (this.execution_Limit.mac < 0) return { status: "failed", body: "The mac device execution limit is less than 0" }

        if (this.repeat_Executable != true && this.repeat_Executable != false) return { status: "failed", body: "The repeat executable value is not a boolean" }

        if (this.minimum_Active_Device_Brand.iphone > this.devices.iphone.length) return { status: "failed", body: "The minimum number of active iphone device is greater than the number of iphone device" }
        if (this.minimum_Active_Device_Brand.android > this.devices.android.length) return { status: "failed", body: "The minimum number of active android device is greater than the number of android device" }
        if (this.minimum_Active_Device_Brand.windows > this.devices.windows.length) return { status: "failed", body: "The minimum number of active windows device is greater than the number of windows device" }
        if (this.minimum_Active_Device_Brand.mac > this.devices.mac.length) return { status: "failed", body: "The minimum number of active mac device is greater than the number of mac device" }

        if (this.maximum_Active_Device_Brand.iphone > this.devices.iphone.length) return { status: "failed", body: "The maximum number of active iphone device is greater than the number of iphone device" }
        if (this.maximum_Active_Device_Brand.android > this.devices.android.length) return { status: "failed", body: "The maximum number of active android device is greater than the number of android device" }
        if (this.maximum_Active_Device_Brand.windows > this.devices.windows.length) return { status: "failed", body: "The maximum number of active windows device is greater than the number of windows device" }
        if (this.maximum_Active_Device_Brand.mac > this.devices.mac.length) return { status: "failed", body: "The maximum number of active mac device is greater than the number of mac device" }

        if (this.execution_Limit.iphone > (this.devices.iphone.length * Object.keys(this.executable).length)) return { status: "failed", body: "The iphone device execution limit is greater than the number of iphone device X the number of executables" }
        if (this.execution_Limit.android > (this.devices.android.length * Object.keys(this.executable).length)) return { status: "failed", body: "The android device execution limit is greater than the number of android device X the number of executables" }
        if (this.execution_Limit.windows > (this.devices.windows.length * Object.keys(this.executable).length)) return { status: "failed", body: "The windows device execution limit is greater than the number of windows device X the number of executables" }
        if (this.execution_Limit.mac > (this.devices.mac.length * Object.keys(this.executable).length)) return { status: "failed", body: "The mac device execution limit is greater than the number of mac device X the number of executables" }

        // in other to keep a min and max active device brand active at all times we would need to have at at least x4 of that device so that we can have a min and max active device brand active at all times
        if (this.maximum_Active_Device_Brand.iphone > (this.devices.iphone.length * 2)) return { status: "failed", body: "The maximum number of active iphone device is greater than the number of iphone device X 2" }
        if (this.maximum_Active_Device_Brand.android > (this.devices.android.length * 2)) return { status: "failed", body: "The maximum number of active android device is greater than the number of android device X 2" }
        if (this.maximum_Active_Device_Brand.windows > (this.devices.windows.length * 2)) return { status: "failed", body: "The maximum number of active windows device is greater than the number of windows device X 2" }
        if (this.maximum_Active_Device_Brand.mac > (this.devices.mac.length * 2)) return { status: "failed", body: "The maximum number of active mac device is greater than the number of mac device X 2" }

        return { status: "success", body: "The botFamily is executable" }


    }

    mission_Completed() {

        /*
            We would loop through the this.execute_count object and check if the value of each key is greater than or equal to the value of the corresponding key in the this.execution_Limit object.
            The aim is to find device brands hasnt reached its execution limit. The device brands that hasnt reached its limit would be added to an array called inComplete_Devices.
        */

        let inComplete_Devices = [];

        for (let device_Brand in this.execute_count) {
            if (this.execute_count[device_Brand] < this.execution_Limit[device_Brand]) inComplete_Devices.push(device_Brand);
        }

        if (inComplete_Devices.length < 1) return { status: "completed", brands: null }

        return { status: "incomplete", brands: inComplete_Devices };

        
    }

    rand(min, max) {
        /*
            This method would be used to generate a random number between a min and max value.
        */

        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    random_Personality_and_Executable(device_Brand, no_of_Personality) {

        /*
            Filters personalities to find those that are available based on the criteria.
            Randomly selects up to the specified number of these available personalities without selecting the same personality more than once.
            For each selected personality, randomly selects one of its available executables.
            Returns an array of objects, each containing a selected personality and its randomly selected executable.
        */

        // Step 1: Filter available personalities
        let availablePersonalities = Object.keys(this.execution_log[device_Brand]).filter(personality => {
            let hasExecutables = Object.keys(this.execution_log[device_Brand][personality]).length > 0;
            let isActive = this.active_Devices[device_Brand].includes(personality);
            return hasExecutables && !isActive;
        });
    
        // Step 2: Randomly select personalities up to the specified number
        let selectedPersonalities = [];
        for (let i = 0; i < Math.min(no_of_Personality, availablePersonalities.length); i++) {
            let randomIndex = Math.floor(Math.random() * availablePersonalities.length);
            selectedPersonalities.push(availablePersonalities[randomIndex]);
            // Remove the selected personality to avoid duplicates
            availablePersonalities.splice(randomIndex, 1);
        }
    
        // Step 3: For each selected personality, pick a random executable
        let personalityExecutablePairs = selectedPersonalities.map(personality => {
            const executables = Object.keys(this.execution_log[device_Brand][personality]);
            const randomExecutableKey = executables[Math.floor(Math.random() * executables.length)];
            const executable = this.execution_log[device_Brand][personality][randomExecutableKey];
            return { [personality]: executable };
        });
    
        return personalityExecutablePairs;
    }

    async launch_Personality_and_Executable(personalityString, executable, device_Brand) {


        await this.sleep(this.rand(1000, 15000));

        let botName = JSON.parse(personalityString).Account.fullname;

        console.log(`We are about to launch ${botName} on a ${device_Brand} device`)


        /*
            We would create a new JavaScript file in a specific folder designated for bots. The name of this file will be the same as the bot's name.
            This new file (also known as a "puppeteer script") is a Node.js script that will be executed as a separate process (child process).
            
            The content of this file is a template string, which includes the 'personality' object that this method receives as an argument.
       */


        let executableString = JSON.stringify(executable, null, 4)

        let scriptTemplate = `
const WebSocket = require('ws');
const person = require("../../HUMAN MODEL/personality.js");
const behavior = require("../../BEHAVIOR MODEL/actions");
const path = require('path');

function getScriptName() {
    // This function returns the name of the script that is currently running
    const fileNameWithExtension = path.basename(__filename);
    const fileNameWithoutExtension = path.parse(fileNameWithExtension).name;
    return fileNameWithoutExtension;
}

var botName = getScriptName();

const modeled =  ${personalityString};

async function runBot() { console.log("${botName} is running...")
    const okecbot = new person(modeled);

    okecbot.showBrowser(false);
    await okecbot.startLife();

    const ws = new WebSocket('ws://localhost:3002');

    ws.on('open', function open() {

        /*         
        Pass the reference of this opened web socket connection to the personality Object that was initiated above.
        ~ The personality method would use this opened socket to a process and exchange json/data with the botEngine
         */

        okecbot.establish_BotFamily_Socket(ws,"${this.name}","${botName}");

        ws.on('error', function error(err) {
            console.error('WebSocket error:', err);
        });

        ws.on('close', function close() {
            console.log('${botName} is disconnected from the botEngine');
        });
    });

    await okecbot.execute_Executable(${executableString}).then((response) => {
       process.exit();
    })


}

runBot();

        
        `;

        fs.writeFile(`bot/WIRE_FRAME/botnet/${botName}.js`, scriptTemplate, function (err) {
            if (err) {
                console.log(err);
            }
            else {
                console.log(`Bot name: ${botName} has been created. Next step is to run the bot`);
            }
        });


        // We would then run the file as a child process using the node.js child_process module.
        await this.launch_Device_File(personalityString, device_Brand);
         
         // now the device has been launched we would delete that executable from the execution log. So that it wouldnt be used again
        delete this.execution_log[device_Brand][personalityString][executable];

        // lets update the execute count
        this.execute_count[device_Brand] += 1;
         
         return "running";

    }

    async launch_Device_File(personality, device_Brand) {

        let botName = JSON.parse(personality).Account.fullname;

        /*
            This method takes in a stringified personality object and a device brand. 
            It parses the stringified personality object into a proper object. 
            It then extracts the Account.fullName property from the object.
            It would then run the file who's path is the extracted botName in the botnet folder as a child process using the node.js child_process module.
            If the process starts successfully, the botName would be added to the list of this.active_Devices[device_Brand].
            If the process crashes or ends successfully, the botName would be removed from the this.active_Devices[device_Brand].
        */

        const botScriptPath = path.join(__dirname, `botnet/${botName}.js`);
        const logPath = path.join(__dirname, `../BOT LOGS/${botName}.log`);

        const childProcess = exec(`node "${botScriptPath}"`, (error, stdout, stderr) => {
            if (error) {
                console.error(`Execution error: ${error}`);
                fs.appendFile(logPath, `Execution error: ${error}\n`, (err) => {
                    if (err) console.error(`Failed to write to log file: ${err}`);
                });
            }

            // if (stdout) console.log(`stdout: ${stdout}`);
            // if (stderr) console.error(`stderr: ${stderr}`);

            this.update_Active_list("de-activate", device_Brand, personality);
        });


        this.update_Active_list("activate", device_Brand, personality);
        return { status: "success", body: "Bot is running" };
    }

    update_Active_list(flow, device_Brand, personality) {
        /*
            This method updates active devices in this.active_Devices[device_Brand].
            It takes in 3 arguments. The first argument is a string representing the action to be taken. The action could be either "activate" or "de-activate".
            The second argument is a string representing the device brand. The third argument is a stringified personality object.

        */

            let botName = JSON.parse(personality).Account.fullname;

        if (flow == "activate") {
            // Add the personality to the array of the (active) device brand if it's not already present
            if (!this.active_Devices[device_Brand].includes(personality)) {
                this.active_Devices[device_Brand].push(personality);
                console.log(`updated active Bot list: added ${pbotName}`)
            }
        } else if (flow == "de-activate") {
            // Remove the botName from the array
            this.active_Devices[device_Brand] = this.active_Devices[device_Brand].filter(obj => obj !== personality);
            console.log(`updated running Bot list: removed ${botName}`)
        }
    }

    shuffle(array) {
        /*
            This method would be used to shuffle an array.
        */

        let currentIndex = array.length, temporaryValue, randomIndex;

        // While there remain elements to shuffle...
        while (0 !== currentIndex) {

            // Pick a remaining element...
            randomIndex = Math.floor(Math.random() * currentIndex);
            currentIndex -= 1;

            // And swap it with the current element.
            temporaryValue = array[currentIndex];
            array[currentIndex] = array[randomIndex];
            array[randomIndex] = temporaryValue;
        }

        return array;
    }



    device_Spawn_Range(device_brand) {
        /*
            This method would be used to get the number of stringified personality object that needs to be launched.
            This method would first get the length of this.active_Devices[device_brand] and minus the value from the minimum number and maximum number of active devices.
            The value of the substraction for the minimum and maximum number of active devices would be used to generate a random number.
            The random number would be returned as the range of devices to be spawned.
        */

        let active_Devices = this.active_Devices[device_brand].length;
        let min = this.minimum_Active_Device_Brand[device_brand];
        let max = this.maximum_Active_Device_Brand[device_brand];

        let range = this.rand(min - active_Devices, max - active_Devices);

        return range;

    }

    async uphold_Execution() {

        /*
            This method would be used to keep the botFamily executing until the mission has been completed.

            Firstly we will check if the botFamily mission has been completed. The mission is said to be completed when all the devices have reached their execution limit.
            If the mission has not been completed, It means one or more device brand has not executed to there limit
            If a device brand has not reached its limit it means we might need to spawn devices and have them execute an executable so as to get closer to there execution (limit).
            In other to do this we would follow the steps below:
            -  If this is the first run, I would like to assume the 4 device brands hasnt reached there limit, how ever as this method is called over and over again,
             some device brands would reach there limit and we wouldnt have to spawn them anymore, only the device brands that hasnt reached there limit would be spawned.
            
            -   The mission_Completed returns an object with compliment_data and status. The compliment_data is an array of device brands that hasnt reached there limit.
            -   We would spawn all the devices in the compliment_data array and then wait for them to be done before existing the try block
        */

            if (this.execution_log == undefined) {
                this.execution_log = {
                    "iphone": {},
                    "android": {},
                    "windows": {},
                    "mac": {}
                }

                for (let device_Brand in this.devices) {
                    for (let device of this.devices[device_Brand]) {
                        this.execution_log[device_Brand][device] = this.executable;
                    }
                }



            }

        console.log(`upholding execution on botFamily ${this.name}`);

        try {

            if (this.mission_Completed().status == "completed") throw "Mission has been completed";

            /* 
                This means the mission has not been completed, so lets spawn the devices yet to reach their limit all at once
                And then wait for them to be done before we continue exit this try block and continue the execution
            */


            let devices_Brands_To_Spawn = this.mission_Completed().brands.map(device => {
                console.log(`We would be spawning a ${device} device`)
                return this.spawn_Devices(device);
            })

            await Promise.allSettled(devices_Brands_To_Spawn);

            console.log("We are done spawning devices")


        } catch (e) {
            console.log(e)
        } finally {
            console.log("upholding execution done")
            await this.sleep(5000);
            this.uphold_Execution();
        }

    }

    async spawn_Devices(device_Brand) {

        /*
            This method would be used to launch devices from a device brand and give them executables to execute.

            Firsty we would check if the device brand already has the minimum number of active devices. If it does, we wouldnt spawn any more devices.
            If it doesnt, we would spawn the number of devices needed to reach the minimum number of active devices.
            To get the number of devices needed to reach the minimum number of active devices, we would call the device_Spawn_Range method.
            
        */


        let range = this.device_Spawn_Range(device_Brand);

        //    console.log(range," We are about to spawn devices")
        if (range == 0) return;

        // We would then call the random_Personality_and_Executable method and give it 2 arguments. argument one is the device brand and argument two is the number of strigified personality from the device brand to be picked at random.
        // The random_Personality_and_Executable method would return an array of objects. Each item in the array would be an object who's key is the stringified personality and the value of the key is a randomly picked executable.
        let executables = this.random_Personality_and_Executable(device_Brand, range);

        // We would then call the launch_Personality_and_Executable method for each item in the array returned by the random_Personality_and_Executable method. we would do this with an await Promise.allSettled method.
        // This would enable us to wait for all the devices to be done before we continue the execution of the uphold_Execution method.
        await Promise.allSettled(executables.map(obj => {
            let personality = Object.keys(obj)[0];
            let executable = obj[personality];
            return this.launch_Personality_and_Executable(personality, executable, device_Brand);
        }));

       // console.log("We are done launching devices")

        return "done";

    }
    



}