

        const WebSocket = require('ws');
const person = require("../../HUMAN MODEL/personality.js");
const behavior = require("../../BEHAVIOR MODEL/actions");
const path = require('path');

function getScriptName() {
    const fileNameWithExtension = path.basename(__filename);
    const fileNameWithoutExtension = path.parse(fileNameWithExtension).name;
    return fileNameWithoutExtension;
}

var botName = getScriptName();


const modeled =  {
    "Account": {
        "fullname": "youtube_ng-0002",
        "OKECBOT_Api_key": "chalz-api"
    },
    "Cookie": [],
    "LocalStorage": [],
    "CookieType": "Idle",
    "Memo": {
        "about": "I am a female from a timezone of Africa/Lagos",
        "device": "I am currently using the Tecno Camon 15,Samsung Galaxy S9,Google Pixel 6 Pro,Google Pixel 4 XL,Google Pixel 6 Pro,Samsung Galaxy S8,Tecno Camon 15,Google Pixel 3,Google Pixel 2,Google Pixel 4 XL,Tecno Pouvoir 4,Google Pixel 6,iPhone 13 Pro Max,iPhone 13 Pro Max,iPhone 13 Mini,iPhone 8 Plus,iPhone 11,iPhone 13 Pro Max,iPhone 11,iPhone 8,iPhone 12 Mini,iPhone XR,iPhone 7,iPhone 12,iPhone XS,iPhone XS,iPhone 13 Mini,iPhone 13 Pro Max,iPhone 7,iPhone XS Max,iPhone 13 Pro,iPhone 12 Pro Max,iPhone 12 Pro,iPhone 13 Pro Max,iPhone 12 Pro,iPhone 13 Pro,iPhone 8,iPhone 7 Plus,iPhone 13,iPhone 11 Pro,iPhone X,iPhone 13 Pro Max,iPhone 12,iPhone 13,iPhone XS Max,iPhone 13 Pro Max,iPhone 13 Mini,iPhone 7 Plus,iPhone 11,iPhone 13 Pro,iPhone 8,iPhone 12 Pro Max,iPhone 11,iPhone 13 Pro Max,iPhone XS,iPhone 11,iPhone 8,iPhone 11,iPhone X,iPhone XR,iPhone 13,iPhone 12 Mini"
    },
    "Device": {
        "resolution": {
            "width": 720,
            "height": 1480
        },
        "userAgent": "Mozilla/5.0 (Linux; Android 8.0; SM-G960U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.137 Mobile Safari/537.36",
        "isMobile": true,
        "hasTouch": true,
        "timeZone": "Africa/Lagos",
        "deviceName": "Samsung Galaxy S9"
    },
    "Location": "NULL"
};

async function runBot() {
    const okecbot = new person();

    // Launching...
    okecbot.modelAccount(modeled.Account);
    okecbot.modelDevice(modeled.Device);
    okecbot.modelLocation(modeled.Location);
    okecbot.modelCookie(modeled.Cookie);
    okecbot.showBrowser(false); // Set headless to true/false as needed

    let okecbotBrowserPage = await okecbot.startLife();
    const actions = new behavior(okecbotBrowserPage[0]);

    const ws = new WebSocket('ws://localhost:3001');

    ws.on('open', function open() {


        ws.on('message', async function incoming(message) {
            const command = JSON.parse(message);
                if( (command.bot) && (command.bot == botName) ){
                console.log('command was made for me', botName);
                    try {
                        switch (command.action) {
                            case 'close-browser':
                                console.log(' just received socket signal to close browser')
                                await okecbotBrowserPage[1].close();
                                break;
                            case 'offBot':
                                console.log(' just received signal to terminate')
                                await process.exit();
                                break;
                            case 'directVisit':
                                await actions.directVisit(command.url);
                                await actions.humanLikeScrollingAndCursorMovement();
                                break;
                            case 'activity-chain':
                                await okecbot.processActivity(okecbotBrowserPage[0],command.activity)
                                break;
                            default:
                                console.log('Unknown command');
                        }
                    } catch (error) {
                        console.error('Error executing command:', error);
                    }
                }
            });
        
            ws.on('error', function error(err) {
                console.error('WebSocket error:', err);
            });
        
            ws.on('close', function close() {
                console.log('WebSocket connection closed');
            });
    });


}

runBot();

        
        