

        const WebSocket = require('ws');
const person = require("../../HUMAN MODEL/personality.js");
const behavior = require("../../BEHAVIOR MODEL/actions");
const path = require('path');

function getScriptName() {
    const fileNameWithExtension = path.basename(__filename);
    const fileNameWithoutExtension = path.parse(fileNameWithExtension).name;
    return fileNameWithoutExtension;
}

var botName = getScriptName();


const modeled =  {
    "Account": {
        "fullname": "youtube_ng-0005",
        "OKECBOT_Api_key": "chalz-api"
    },
    "Cookie": [],
    "LocalStorage": [],
    "CookieType": "Idle",
    "Memo": {
        "about": "I am a male from a timezone of Africa/Lagos",
        "device": "I am currently using the Google Pixel 6,Tecno Pouvoir 4,HTC 10,Google Pixel 3,Tecno Spark 5,HTC One M9,Google Pixel 6 Pro,Samsung Galaxy S9,Google Pixel 2,Infinix Zero 8,Google Pixel 3,Google Pixel 4 XL,iPhone 12 Pro,iPhone XS,iPhone 13 Pro Max,iPhone 11,iPhone 8,iPhone 12 Pro,iPhone XR,iPhone 11,iPhone SE (2nd generation),iPhone 12 Pro,iPhone 12 Mini,iPhone XR,iPhone 13,iPhone 8 Plus,iPhone 11 Pro,iPhone 12,iPhone 8,iPhone 11,iPhone 13 Mini,iPhone 12 Mini,iPhone XS,iPhone XR,iPhone 12 Mini,iPhone XR,iPhone 13 Pro,iPhone 11,iPhone XS Max,iPhone 13,iPhone XR,iPhone XR,iPhone 12,iPhone 12,iPhone 7,iPhone 13 Pro,iPhone 13,iPhone 12 Pro Max,iPhone 8,iPhone 11 Pro Max,iPhone 11 Pro Max,iPhone 12 Pro Max,iPhone XS,iPhone XS,iPhone 11 Pro Max,iPhone 7 Plus,iPhone 11,iPhone X,iPhone XS,iPhone 13 Mini,iPhone 12 Pro Max,iPhone 12 Pro Max"
    },
    "Device": {
        "resolution": {
            "width": 360,
            "height": 800
        },
        "userAgent": "Mozilla/5.0 (Linux; Android 10.0; Tecno KD7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Mobile Safari/537.36",
        "isMobile": true,
        "hasTouch": true,
        "timeZone": "Africa/Lagos",
        "deviceName": "Tecno Spark 5"
    },
    "Location": "NULL"
};

async function runBot() {
    const okecbot = new person();

    // Launching...
    okecbot.modelAccount(modeled.Account);
    okecbot.modelDevice(modeled.Device);
    okecbot.modelLocation(modeled.Location);
    okecbot.modelCookie(modeled.Cookie);
    okecbot.showBrowser(false); // Set headless to true/false as needed

    let okecbotBrowserPage = await okecbot.startLife();
    const actions = new behavior(okecbotBrowserPage[0]);

    const ws = new WebSocket('ws://localhost:3001');

    ws.on('open', function open() {


        ws.on('message', async function incoming(message) {
            const command = JSON.parse(message);
                if( (command.bot) && (command.bot == botName) ){
                console.log('command was made for me', botName);
                    try {
                        switch (command.action) {
                            case 'close-browser':
                                console.log(' just received socket signal to close browser')
                                await okecbotBrowserPage[1].close();
                                break;
                            case 'offBot':
                                console.log(' just received signal to terminate')
                                await process.exit();
                                break;
                            case 'directVisit':
                                await actions.directVisit(command.url);
                                await actions.humanLikeScrollingAndCursorMovement();
                                break;
                            case 'activity-chain':
                                await okecbot.processActivity(okecbotBrowserPage[0],command.activity)
                                break;
                            default:
                                console.log('Unknown command');
                        }
                    } catch (error) {
                        console.error('Error executing command:', error);
                    }
                }
            });
        
            ws.on('error', function error(err) {
                console.error('WebSocket error:', err);
            });
        
            ws.on('close', function close() {
                console.log('WebSocket connection closed');
            });
    });


}

runBot();

        
        