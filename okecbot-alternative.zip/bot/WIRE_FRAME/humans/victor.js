
const WebSocket = require('ws');
const person = require("../../HUMAN MODEL/personality.js");
const behavior = require("../../BEHAVIOR MODEL/actions");
const path = require('path');

function getScriptName() {
    // This function returns the name of the script that is currently running
    const fileNameWithExtension = path.basename(__filename);
    const fileNameWithoutExtension = path.parse(fileNameWithExtension).name;
    return fileNameWithoutExtension;
}

var botName = getScriptName();

const modeled =  {
    "Account": {
        "fullname": "victor",
        "OKECBOT_Api_key": "chalz-api"
    },
    "Device": {
        "resolution": {
            "width": 1366,
            "height": 768
        },
        "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36",
        "isMobile": false,
        "hasTouch": false,
        "timeZone": "Africa/Lagos",
        "deviceName": "Windows 7 1366 x 768"
    },
    "Location": "NULL",
    "Cookie": [],
    "LocalStorage": {}
};

async function runBot() {
    const okecbot = new person(modeled);

    okecbot.showBrowser(false); // Set headless to true/false as needed
    await okecbot.startLife();

    const ws = new WebSocket('ws://localhost:3001');

    ws.on('open', function open() {

        /*         
        Pass the reference of this opened web socket connection to the personality Object that was initiated above.
        ~ The personality method would use this opened socket to a process and exchange json/data with the botEngine
         */

        okecbot.set_Communicator_Socket(ws,botName);

        ws.on('error', function error(err) {
            console.error('WebSocket error:', err);
        });

        ws.on('close', function close() {
            console.log('victor is disconnected from the botEngine');
        });
    });


}

runBot();

        
        