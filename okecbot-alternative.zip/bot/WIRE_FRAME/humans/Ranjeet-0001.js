
const WebSocket = require('ws');
const person = require("../../HUMAN MODEL/personality.js");
const behavior = require("../../BEHAVIOR MODEL/actions");
const path = require('path');

function getScriptName() {
    // This function returns the name of the script that is currently running
    const fileNameWithExtension = path.basename(__filename);
    const fileNameWithoutExtension = path.parse(fileNameWithExtension).name;
    return fileNameWithoutExtension;
}

var botName = getScriptName();

const modeled =  {
    "Account": {
        "fullname": "Ranjeet-0001",
        "OKECBOT_Api_key": "chalz-api"
    },
    "Cookie": [],
    "LocalStorage": [],
    "CookieType": "Idle",
    "Memo": {
        "about": "I am a female from a timezone of America/Los_Angeles",
        "device": "I am currently using the Pixel 5,HTC U11+,Xiaomi Mi 10,OnePlus 8 Pro,LG Nexus 5,Apple iPhone 12,Apple iPhone 13 Mini,Apple iPhone 15,Mac OS X 10.7 Lion 1440 x 900,Mac OS X 10.6 Snow Leopard 1280 x 800,Windows 7 1280 x 720,Windows XP 1024 x 768,Windows 8.1 1920 x 1080"
    },
    "Device": {
        "resolution": {
            "width": 393,
            "height": 851
        },
        "userAgent": "Mozilla/5.0 (Linux; Android 11; Pixel 5 Build/RQ1A.210205.004; wv) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36",
        "isMobile": true,
        "hasTouch": true,
        "timeZone": "America/Los_Angeles",
        "deviceName": "Pixel 5"
    },
    "Location": {
        "proxyType": "http",
        "proxyServer": "http://a41dd34b93c30ac4.zqz.na.pyproxy.io:16666",
        "proxyUsername": "google12-zone-resi-region-us-session-79cb33d4602f-sessTime-120",
        "proxyPassword": "pass07"
    }
};

async function runBot() {
    const okecbot = new person(modeled);

    okecbot.showBrowser(false); // Set headless to true/false as needed
    await okecbot.startLife();

    const ws = new WebSocket('ws://localhost:3001');

    ws.on('open', function open() {

        /*         
        Pass the reference of this opened web socket connection to the personality Object that was initiated above.
        ~ The personality method would use this opened socket to a process and exchange json/data with the botEngine
         */

        okecbot.set_Communicator_Socket(ws,botName);

        ws.on('error', function error(err) {
            console.error('WebSocket error:', err);
        });

        ws.on('close', function close() {
            console.log('Ranjeet-0001 is disconnected from the botEngine');
        });
    });


}

runBot();

        
        