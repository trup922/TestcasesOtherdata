// require your node modules
const bot = require("puppeteer-extra");

// add stealth plugin and use defaults (all evasion techniques) 
const StealthPlugin = require('puppeteer-extra-plugin-stealth')
bot.use(StealthPlugin())
const { executablePath } = require('puppeteer')
const { DateTime } = require('luxon');
const readline = require('readline');
const axios = require('axios').default;
const fs = require("fs");

// The platform executables::
const browser = require("../BEHAVIOR MODEL/usage/toolBox/browser");
const away_Time = require("../BEHAVIOR MODEL/usage/toolBox/away_Time");

module.exports = class Human {


  constructor(modeled) {
    this.Account = null;
    this.Device = null;
    this.Location = null;
    this.Cookies = null;
    this.headless = false;
    this.executeReport = null;

    this.browser = null;
    this.botName = null;

    this.memo = {
      status: "idle",
      logs: []
    };

    this.botName_modeled_personality = modeled;

    // Launch configuration.
    this.modelAccount(this.botName_modeled_personality.Account);
    this.modelDevice(this.botName_modeled_personality.Device);
    this.modelLocation(this.botName_modeled_personality.Location);
    this.modelCookie(this.botName_modeled_personality.Cookie);



  }

  establish_BotFamily_Socket(ws, botFamily_Name, botFamily_botName) {
    /*
      This method is called  by a botFamily device that has been launched.
      The argument received is the websocket instance of the botFamily device that has been launched.
    */

    this.ws = ws;
    this.botFamily_Name = botFamily_Name;
    this.botName = botFamily_botName;

    const message = {
      type: "botFamily",
      botFamily_Name: this.botFamily_Name,
      botFamily_botName: this.botName
    };

    this.ws.send(JSON.stringify(message));

    this.process_Message_From_BotEngine();


  }


  set_Communicator_Socket(ws, botName) {
    // Pass a reference of the initiated websocket of the bot script to this method 
    // This method can then use the websocket instance to receive and process messages
    // send feedback of task executions to the botEngine and finally execute commands received from
    // bot Engine, such as visit a website, save cookie to okecbot database through an end point
    // & customly iterate the chain of commands / activites receieved by the botEngine
    this.ws = ws;
    this.botName = botName;

    const message = {
      type: 'clientName',
      name: botName,
    };
    this.ws.send(JSON.stringify(message));

    this.process_Message_From_BotEngine();

    this.set_Memo_And_Update_BotEngine("log", this.botName_first_Launch_log)
  }

  async set_Memo_And_Update_BotEngine(type, data) {
    /*
      When ever we are supposed to console log a message, we would instead push the message to the memo object (logs array)
      We would also update the status of the bot to the memo object. after updating the memo object, we would send the memo object to the botEngine
    */

    if (type == "log") {
      this.memo.logs.push(data);
    } else if (type == "status") {
      this.memo.status = data;
    }

    await this.ws.send(JSON.stringify(this.memo));
  }

  async execute_Executable(executable) {
    /*
      When a botFamily makes a bot it gives it an executable to execute.
      This executable is interpreted by the bot and executed.

      Firstly we must interpret the executable and then execute it.
    */

    let executor_method = Object.keys(executable)[0];

    let executor_name = executable[executor_method]["name"];
    let executor_requirement = JSON.stringify(executable[executor_method]["requirement"]);
    let executor_secondary = JSON.stringify(executable[executor_method]["secondary"]);

    let javascript_evaluable_string = ` this.${executor_method}.${executor_name}(${executor_requirement},${executor_secondary})`;

    console.log(javascript_evaluable_string);


    try {

      let i = await eval(javascript_evaluable_string);

      console.log(i);

      return "Executable executed successfully!";

    } catch (e) {
      return
    }

  }

  process_Message_From_BotEngine() {

    /*
    This method is called when the botEngine sends a message to this botName instance.
    This method would first parse the message, interprete it then execute the command interepreted.
    If the command is to execute a chain of activities, this method would call the interprete_Received_Activity_Chain_Object method
    otherwise it would execute the command received such as save State or just shutDown the bot script (process.exit()
    */

    this.ws.on('message', async (message) => {
      const parsed_message = JSON.parse(message);

      try {
        switch (parsed_message.department) {

          case 'shutDown':
            this.set_Memo_And_Update_BotEngine("logs", `bot: ${this.botName} just received a signal to deactivate now! `);
            this.set_Memo_And_Update_BotEngine("status", "idle");
            process.exit();
            break;

          case 'terminate_execution':
            /*
              We would terminate the execution of the activity by setting the status of the bot to terminate_now
              But this would work only when the status is at executing. if is not at executing, we would not terminate the execution
            */
            if (this.memo.status != "executing") {
              this.set_Memo_And_Update_BotEngine("logs", `bot: ${this.botName} Can not terminate because no execution is currently running!`);
              break;
            }
            this.set_Memo_And_Update_BotEngine("logs", `bot: ${this.botName} just received a signal to terminate execution now! `);
            this.set_Memo_And_Update_BotEngine("status", "terminate_now");
            break;

          case 'save_state':
            console.log(" save state category!! ")
            await this.set_Memo_And_Update_BotEngine("status", "executing");
            await this.set_Memo_And_Update_BotEngine("log", `bot: ${this.botName} is currently saving its state to okecbot server (cookies, local storage and finger prints meta data) `);
            let response = await this.save_BotName_State(this.botName_modeled_personality);
            await this.set_Memo_And_Update_BotEngine("status", "idle");
            await this.set_Memo_And_Update_BotEngine("log", response);
            break;


          case 'activity_chain':
            /*
              We would first check if the bot is currently executing an activity chain.
              If it is executing an activity chain, we would not execute the new activity chain received.
              If it is not executing an activity chain, we would execute the new activity chain received.
            */
            if (this.memo.status == "executing") {
              await this.set_Memo_And_Update_BotEngine("log", `bot: ${this.botName} is currently executing an activity chain, so it would not execute the new activity chain received! `);
              break;
            }
            await this.set_Memo_And_Update_BotEngine("status", "executing");
            await this.set_Memo_And_Update_BotEngine("log", `bot: ${this.botName} just received a signal to execute a chain of activities now! `);
            await this.set_Memo_And_Update_BotEngine("log", `bot: ${this.botName} are now interpreting the activity chain object received! `);
            let activity_Javascript_Evalable_Array = await this.interprete_Received_Activity_Chain_Object(parsed_message.compliment_data);

            for (let activity of activity_Javascript_Evalable_Array) {

              /* 
                  This is where we try to execute each activity and send back a feedback to the botEngine
                  so it can then update the dashboard if the execution was succesfful or not

                  but firstly we would have to set the memo object to set to terminate_now so the bot can stop executing the activity chain if it is break the loop 
                  If it breaks all the loop because terminate_now is the value of this.memo.status, It would at the end of the loop set the this.memo.status back to idle
                  And then newer activities can be executed.
              */

              if (this.memo.status == "terminate_now") {
                break;
              }

              await this.set_Memo_And_Update_BotEngine("log", `bot: ${this.botName} is now executing the activity chain! below `);
              await this.set_Memo_And_Update_BotEngine("log", `activity: ${activity}`);

              console.log(`bot: ${this.botName} is now executing the activity chain! below `);
              console.log(`activity: ${activity}`);

              try {

                let activity_Chain_Execution_response = await eval(activity);
                await this.set_Memo_And_Update_BotEngine("log", "Activity executed successfully! ");

                console.log("Activity executed successfully! ", activity_Chain_Execution_response);

              } catch (e) {
                await this.set_Memo_And_Update_BotEngine("log", "Activity execution failed!, contatc okecbot support team and describe the activity you werfe trying to execute! ");
                console.log(e)
              }

            }

            this.set_Memo_And_Update_BotEngine("status", "idle");
            this.set_Memo_And_Update_BotEngine("logs", `bot: ${this.botName} has finished executing the activity chain!`)
            break;


          default:
            console.log('Unknown department');
        }
      } catch (error) {
        console.error('Error executing command:', error);
      }

    });

  }

  async interprete_Received_Activity_Chain_Object(activity, orderly) {

    /*
      This method would interprete the activity chain object received from the botEngine.
      
      How does it acheive this you ask ?:
      The activity is usually an object with keys. each key is an activity to be executed.
      The value of each key is an executor. example of an executor is: youtube,audio mack, google, instagram, facebook, twitter, linkedin, etc.
      We call it executor because it basically a class that has been instantiated at the beginning of the bot script.
      if you look at the require modules you would find a comment under which says " The platform executables " 
      This executables are instantiated at the beginning of the bot script and are used to execute the activities a method in there class

      :: To make it easier to understand, each of the executables is a class that has a methods
      this methods taking in parameters in other to execute a task. example of a method is: youtube.search("search query")


      Now back the where we left of (executables).
      each of the executables has another object with 3 fundamental keys.
      The keys are:
        ***:: name: <= The name property is simply the method to execute within the executable class. (example: find_video, stream_video)
        ***:: requirement: <= The requirement property is simply the parameters to pass to the method to be executed. (example: search query, video url)
        ***:: seconday: <= This are further action that can be executed after the primary action has been executed. (example: video_Link_ToMatch, comment, subscribe, thumbsUp, thumbsDown, etc)

      Now that we have understood the structure of the activity chain object, lets now look at how we would interprete it.
      We would first loop through the activity object and get the keys of the object.
      We would then use the keys to get the executor of the activity.
      we would get the first key of the executor.
      We would then use the executor to get the name, requirement and secondary of the activity.
      We would then use the name, requirement and secondary to build a javascript evaluable string.
      We would then push the javascript evaluable string to an array.
      We would then return the array of javascript evaluable string.
      The botEngine would then loop through the array and execute each javascript evaluable string.
      The botEngine would then send a feedback to the dashboard if the execution was succesfful or not.
    */

    let activity_Javascript_Evalable_Array = [];
    let activity_keys = Object.keys(activity);


    activity_keys.forEach(key => {

      let executor = activity[key];

      let executor_method = Object.keys(executor)[0];

      let executor_name = executor[Object.keys(executor)[0]];
      let executor_requirement = JSON.stringify(executor_name.requirement);
      let executor_secondary = JSON.stringify(executor_name.secondary);

      let javascript_evaluable_string = `this.${executor_method}.${executor_name["name"]}(${executor_requirement},${executor_secondary})`;

      activity_Javascript_Evalable_Array.push(javascript_evaluable_string);

    });

    return activity_Javascript_Evalable_Array;
  }

  getCurrentDateTimeInTimezone(timezone) {
    // Set the locale to ensure the month is displayed in English
    const dateTime = DateTime.now().setZone(timezone).setLocale('en-US');

    // Format the date and time
    const formattedDate = dateTime.toFormat("dd'th' LLL yyyy HH:mm a");

    return formattedDate;
  }

  modelAccount(Account) {
    this.Account = Account;
  }

  modelDevice(Device) {
    this.Device = Device;
  }

  modelLocation(Location) {
    this.Location = Location;
  }

  modelCookie(Cookies) {
    this.Cookies = Cookies;
  }

  showBrowser(status) {
    this.headless = status;
  }

  getProxy() {

    if (this.Location != "NULL") {
      return `--proxy-server=${this.Location.proxyServer}`
    } else {
      return ``;
    }

  }

  async startLife() {

    // get the proxy details
    let username = this.Location.proxyUsername;
    let password = this.Location.proxyPassword;
    let cookie = this.Cookies;


    // Load the bot configurations
    const botConfiguration = {
      headless: this.headless,
      executablePath: executablePath(),
      ignoreHTTPSErrors: true,
      defaultViewport: this.Device.resolution,
      args: [this.getProxy(), `--window-size=${this.Device.resolution.width},${this.Device.resolution.height}`, '--no-sandbox', '--disable-setuid-sandbox', '--disable-features=WebRtcHideLocalIpsWithMdns',
        '--disable-webrtc-encryption',
        '--disable-webrtc-multiple-routes']
    };

    // Launch the browser here (chrome)
    this.chromeBrowser = await bot.launch(botConfiguration);


    this.chromeBrowserPage = await this.chromeBrowser.newPage();


    // Set the timezone to New York (Eastern Time)
    await this.chromeBrowserPage.emulateTimezone(this.Device.timeZone);
    if (this.Location != "NULL") {
      console.log(" Ip proxy time loll")
      // Authenticate our proxy with username and password defined above
      await this.chromeBrowserPage.authenticate({ username, password });
    } else {
      console.log("browsering from local network since no proxy detected")
    }
    // set the useragent
    await this.chromeBrowserPage.setUserAgent(this.Device.userAgent);
    // set the Cookie
    await this.chromeBrowserPage.setCookie(...cookie);

    await this.chromeBrowserPage.setViewport({
      width: this.Device.resolution.width,  // Example width
      height: this.Device.resolution.height,  // Example height
      isMobile: this.Device.isMobile,
      hasTouch: this.Device.hasTouch,  // Often used with isMobile to simulate touch
      deviceScaleFactor: 2  // Example device scale factor (e.g., for retina screens)
    });




    this.botName_first_Launch_log = `bot: ${this.Account.fullname}  has started life on ${this.Device.deviceName} tunneling through ${this.Location.proxyServer} proxy!. Timezone is at ${this.Device.timeZone} and so the current time on " ${this.Account.fullname} " machine is ${this.getCurrentDateTimeInTimezone(this.Device.timeZone)}`;

    this.chromeBrowserPage.goto("https://okecbot.info", { waitUntil: 'domcontentloaded' })

    // Now we have successfully launched the browser, we would instantiate the executables with the chromeBrowserPage object
    this.browser = new browser(this);
    this.away_Time = new away_Time(this);
    // this.google = new google(this.chromeBrowserPage);

  }

  sleep(ms) {
    // Majority of our activities such as pinging a bot or waiting for a process requires a delay.
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async logOffHuman() {
    await this.chromeBrowser.close();
  }

  async save_BotName_State(modeled) {

    /*
      This method would get the current cookie and local storage of this current instantiated botName 
      
      In other to make our bots undetectable, we would need to make them look like a typical human browser that is used often.
      humans often have a cookie and local storage indicating there session on a website.
      This method would get the current cookie and local storage of this current instantiated botName and
      save it on our okecbot sever for backup. 
    */

    let cookies = await this.getCookies();
    let localStorage = await this.getLocalStorage();

    // building a fully fledged personality meta data
    let personality = {
      Account: modeled.Account,
      Device: modeled.Device,
      Location: modeled.Location,
      Cookie: cookies,
      LocalStorage: localStorage,
      Type: modeled.CookieType
    }

    return await this.upload_BotName_State(personality);
  }


  async upload_BotName_State(personality) {
    /*
      This method would upload the current state of the botName to our okecbot server for backup.
      This method would also update the botName state on our okecbot server if the botName state already exists on our server.
    */
    let updated_State = JSON.stringify(personality);

    await axios.post(`https://okecbot.com/api/index.php?key=${personality.Account.OKECBOT_Api_key}&save_state`, {

      "botName": personality.Account.fullname, "personality": updated_State

    }).then(function (response) {
      console.log(response.data);
    }).catch(e => {
      console.log(e);
    })
  }

  async getCookies() {
    const cookies = await this.chromeBrowserPage.cookies();
    return cookies;
  }

  async getLocalStorage() {
    // Get localStorage data
    const localStorageData = await this.chromeBrowserPage.evaluate(() => {
      const data = {};
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        const value = localStorage.getItem(key);
        data[key] = value;
      }
      return data;
    });

    // Store the localStorage data in a file
    const localStorageDataJSON = localStorageData;
    return localStorageDataJSON;
  }






}
