const express = require('express');
const path = require('path');
const cors = require('cors'); // Import the cors middleware
const app = express();
const botEngine = require('./bot/WIRE_FRAME/botEngine');
const botNet = require('./bot/WIRE_FRAME/botAi');
const control = require('./bot/BEHAVIOR MODEL/usage/index');
const fs = require('fs').promises; // Use fs.promises for async file operations

// Initiate object needed
var ws = null; // holder for socket, should we need to broacast
const botMaker = new botEngine(); // object to making and managing bot
const botControls = new control(); // object to execute actions
const botNetSystem = new botNet(botMaker); // object to inform botNet on actions to execute and how to execute them


const WebSocket = require('ws');
ws = new WebSocket('ws://localhost:3001');


// Configure cors to allow requests from your frontend origin
const corsOptions = {
  origin: '*',
  optionsSuccessStatus: 200, // Some legacy browsers (IE11, various SmartTVs) choke on 204
};

app.use(cors(corsOptions)); // Use the cors middleware with your options


app.use(express.static('website'));  // Serve static files from the 'website' directory
app.use(express.json())

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'website/index.html'));  // Serve your dashboard HTML file
});


app.post('/power_botName', async (req, res) => {
  /*
  request sent to this endpoint would be have 3 mandatory properties. 
  first property is the botName. example "audiomack-0001"
  second property is the action to be taken which would be either "activate" or "de-activate"
  third property is the additional data the seond property might need to execute example a personality object for creating a new bot
  If no additional data is needed, the third property should be null.

  example:
  req = { botName: "audiomack-0001", action: "de-activate", compliment_data: null }.

  this function takes the on-bot and off-bot function and combines them into one function.
  */

  let botName = req.body.botName;
  let action = req.body.action;
  let compliment_data = req.body.compliment_data;
  try {
    if (action == "activate") {
      let response = await botMaker.makeBot(compliment_data.personality, compliment_data.headless);
      res.send(response)
    } else if (action == "de-activate") {
      let response = await botMaker.showDown_BotName(botName)
      res.send(response)
    } else {
      res.send({ status: "failed", body: "confused at what kind of power you intend to exert on " + botName })
    }
  } catch (e) {
    console.log(e)
  }


});

app.post('/execute_botName', async (req, res) => {

  /*
  This function would take the request and pass it to the botEngine to execute it on a selected bot.
  */

  try {
    let response = await botMaker.execute_Action_On_BotName(req.body); // pass the request to the botEngine and save response on this variable
    res.send(response); // send the response to the client who made the request so they can know if the request was successful or not

  } catch (e) {
    console.log(e)
    res.send({ status: "failed", body: " Couldnt call the execute method! " })
  }


});

app.post('/botNet', async (req, res) => {
  /* 
    This endPoint would receive a botNet request and pass it to the internal botNet system to execute.
    specifically it should pass it to the botNet interpreter.
  */
  try {
    let response = await botNetSystem.processRequest(req.body); // pass the request to the botEngine and save response on this variable
    res.send(response); // send the response to the client who made the request so they can know if the request was successful or not

  } catch (e) {
    console.log(e)
    res.send({ status: "failed", body: " Couldnt call the execute method! " })
  }
});

app.post('/isRunning', async (req, res) => {
  let botName = req.body.botName;
  try {
    let botBtatus = await botMaker.check_BotName_On_RunningBot_List(botName)
    res.send({ status: botBtatus })

  } catch (e) {
    console.log(e)
  }
});

app.post('/logout', async (req, res) => {
  try {
    const filePath = path.join(__dirname, 'website/login/key.json');

    // Log the file path for debugging
    console.log('File Path:', filePath);

    // Read the existing content of the file
    const existingContent = await fs.readFile(filePath, 'utf8');

    // Log the existing content for debugging
    console.log('Existing Content Before Update:', existingContent);

    // Parse the existing content as JSON
    const existingData = JSON.parse(existingContent);

    // Update the apiKey property with the received key
    existingData.apiKey = null;

    // Write the updated data back to the file
    await fs.writeFile(filePath, JSON.stringify(existingData, null, 2));

    // Log the updated content for debugging
    console.log('Updated Content:', JSON.stringify(existingData, null, 2));

    res.status(200).json({ status: 'success', message: 'Logout Success' });
  } catch (error) {
    res.status(500).json({ status: 'error', message: 'Internal Server Error' });

    // Log the error for debugging
    console.error(error);
  }
});


app.post('/controller', async (req, res) => {

  /* 
     This function would respond with the information regarding the controls a user can make on a botName.
     In other to allow users create activities we created a set of controls that can be used to create activities.
     this controls are usually updated everytime we complete a new activity.

     The sole process of this endPoint is to respond with the controls a user can make on a botName and additionally verify if the
     user programmed there activity properly

     Functions of this endPoint:
     Firstly, to show what can be programmed (control options and requirements needed to execute that control)
     Secondly, to verify if the user programmed the activity properly 
     */

  try {

    let request = req.body;
    let response = await botControls.processRequest(request);
    res.send(response)
  } catch (e) {
    console.log(e)
    res.send({ status: "failed" })
  }


})



app.post('/save-apiKey', async (req, res) => {
  try {
    let newApiKey = req.body.apiKey;

    if(newApiKey === null || newApiKey === undefined || newApiKey === ''){
      res.status(400).json({ status: 'error', message: 'API Key cannot be empty' });
      return;
    }

    // Log the incoming API key to the server console
    console.log('Received API Key:', newApiKey);

    // Define the file path
    const filePath = path.join(__dirname, 'website/login/key.json');

    // Read the existing content of the file
    const existingContent = await fs.readFile(filePath, 'utf8');

    // Parse the existing content as JSON
    const existingData = JSON.parse(existingContent);

    // Update the apiKey property with the received key
    existingData.apiKey = newApiKey;

    // Write the updated data back to the file
    await fs.writeFile(filePath, JSON.stringify(existingData, null, 2));

    // Send a response to the client
    res.status(200).json({ status: 'success', message: 'API Key saved successfully' });
  } catch (error) {
    console.error(error);
    // Send an error response to the client if something goes wrong
    res.status(500).json({ status: 'error', message: 'Internal Server Error' });
  }
});


const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
