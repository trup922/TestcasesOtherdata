/*
    This class would be focused on managing the executable list also know as chain of Actions.

    Compiling/Adding an action into the executable list and executable object history:
    This class would loop through the control info class (a class used to mark primary/secondary inputs)
    The inputs value would then be packed into an object and upon request to add the action to the executable list,
     the object would be first validated and then added to the executable list and the history object.

     Editing a saved action:
     This class would also provide access to load a previously save executable object and then allow the user to edit the actions in the object.
     The user would be able to remove an action, change the order of the actions, or change the value of an action.
*/

import { validateExecutable } from './validate-Executable.js';

export class renderExecutable {

    constructor(executableManager) {
        console.log("renderExecutable class created")
        this.executableManager = executableManager;
        this.executableHistory = {};
        this.addChainSlate = "clean";
        this.editMode = null;
        this.validateExecutable = new validateExecutable(this);

        this.relisten();
    }

    getTimeStamp() {
        return new Date().getTime();
    }

    async main() {
        this.relisten();
    }

    waitForElement(selector, timeout = 3000) {
        return new Promise((resolve, reject) => {
            const intervalTime = 100; // Check every 100 ms
            let elapsedTime = 0;

            const interval = setInterval(() => {
                const element = document.querySelector(selector);
                if (element) {
                    clearInterval(interval);
                    resolve(element);
                } else if (elapsedTime > timeout) {
                    clearInterval(interval);
                    reject(new Error(`${selector} not found within timeout period`));
                }
                elapsedTime += intervalTime;
            }, intervalTime);
        });
    }

    reorder_OBJ(originalObj, newItem, index) {
        // Convert the original object to an array of [key, value] pairs
        let entries = Object.entries(originalObj);

        // Insert the new item at the specified index
        // Note: newItem should also be a [key, value] pair
        entries.splice(index, 0, newItem);

        // Convert the array back to an object
        let reorderedObj = {};
        entries.forEach(([key, value]) => {
            reorderedObj[key] = value;
        });

        return reorderedObj;
    }

    async renderHistory() {
        // This method would be used to render the history of the executable list to the user.

        // empty the container
        $("#activityContainer").empty();

        let self = this;

        if (Object.keys(self.executableHistory).length < 1) return; // if we havent added any action to the executable list, then we should not render anything

        // Count the devices
        let count = 0;

        for (const act in self.executableHistory) {
            if (self.executableHistory.hasOwnProperty(act)) {

                let indx = count;
                count = count + 1;

                console.log("Rendering the history of the executable list", act);

                let obj = self.executableHistory[act];

                // build a div card for the action
                let tool = Object.keys(obj)[0];
                let actions = obj[tool].requirement;
                let secondaryActions = obj[tool].secondary;
                let memo = "";
                let memoSecondary = "";

                for (const key in actions) {
                    if (actions.hasOwnProperty(key)) {
                        memo += `<div> ${key} : ${actions[key]} </div>`;
                    }
                }

                for (const key in secondaryActions) {
                    if (secondaryActions.hasOwnProperty(key)) {
                        memoSecondary += `<div> ${key} : ${secondaryActions[key]} </div>`;
                    }
                }

                // get the imgSrc
                let imgSrc = self.executableManager.toolIcons[tool];

                //delete obj["mission"] // this was to delete the mission key from the object

                let template = `
                                <div id="${act}"  class="card cardAct bg-secondary mx-auto">

                                        <div class="d-flex bg-dark card-title justify-content-between" >
                                            <img style="max-width:40px" src="${imgSrc}" />
                                            <h6 class="text-white ml-3 mt-2 text-capitalize">  ${tool} Tool </h6>
                                            <button category="delete" name="${act}"  class="btn renderBtn small btn-danger">Delete</button>
                                        </div>
                                        
                                        <div class="card-body ">
                                       
                                                <div>
                                                    <div> ${obj[tool].name} </div>
                                                    <hr>
                                                    <div class="small" > ${memo} </div>
                                                </div>


                                                <div class="mt-4">
                                                    <hr>
                                                    <div class="small" > ${memoSecondary} </div>
                                                </div>
                     
                                        </div>

                                        <div style="width:75px; bottom:-14px; position:relative;  font-size:24px; height:40px;" class="text-danger btn bg-light text-center ml-auto">
                                            <img style="width:35px;" index="${indx}" category="edit"  name="${act}" class="renderBtn" src="images/edit-icon.png" />
                                            ${count}
                                        </div>

                                </div>
            
            `;

                // clear the inputs by rendering the primary and secondary again
                $("#activityContainer").append(template)

            }
        };

    }

    add_Action(obj) {

        let act;
        if (this.editMode == null) {
            // create a unique key for the action
            act = `act-${this.getTimeStamp()}`;
            // save the action to the history
            this.executableHistory[act] = obj;

        } else {
            // this means we are currently editing an action
            act = this.editMode.name;
            let newItem = [act, obj];
            this.executableHistory = this.reorder_OBJ(this.executableHistory, newItem, this.editMode.index);
            this.editMode = null;
        }
    }

    async compile_Action() {
        let controls = {};

        await Promise.all($('.control-info').map(async function () {
            const prop = $(this).attr("name");
            const val = $(this).val();
            const id = $(this).attr("category");
            const path1 = $("#tool-box").val();
            let categoryKey;

            switch (id) {
                case "tool-box":
                    controls[val] = "";
                    break;
                case "tool-action":
                    controls[path1] = { "name": $("#tool-action option:selected").text().trim() };
                    break;
                case "primary":
                    categoryKey = "requirement";
                    break;
                default:
                    categoryKey = "secondary";
            }

            if (categoryKey) {
                if (!controls[path1]) controls[path1] = {};
                if (!controls[path1][categoryKey]) controls[path1][categoryKey] = {};
                controls[path1][categoryKey][prop] = val;
            }
        }));

        return controls;

    }

    async relisten() {


        // re listen to events since dynamic content has been added

        let self = this;

        let chainBoard = await this.waitForElement("#activityContainer");
        $(chainBoard).sortable({
            update: function (event, ui) {
                let newOrder = $(this).sortable('toArray'); // This will get the new order of IDs
                let newHistory = {};

                // Loop through the new order array and reconstruct the executableHistory based on the new order
                newOrder.forEach(id => {
                    if (self.executableHistory[id]) {
                        newHistory[id] = self.executableHistory[id];
                    }
                });

                // Replace the old executableHistory with the new ordered one
                self.executableHistory = { ...newHistory };

                // Optionally, you can re-render the history or perform other actions needed after reordering
                self.relisten();;
            }

        });

        // render the history of the executable list,and re listen to events below
        this.renderHistory();

        await $("#addActivity").off("click").on("click", async function () {

            let obj = await self.compile_Action()

            let validate = await self.validateExecutable.validate(obj);

            if (!validate) return;

            if (self.addChainSlate == "staged") {
                let prompt = await self.executableManager.renderEngine.popPrompt(
                    {
                        title: "Add Action Again?",
                        note: "This exact action was last added to the executable list a while ago, are you sure you want to add it again?"
                    });

                if (prompt == "confirmed") {
                    self.add_Action(obj);
                    self.addChainSlate = "staged";
                    self.relisten();
                    return;
                } else {
                    return;
                }

            }

            self.add_Action(obj);
            self.addChainSlate = "staged";

            // re listen to events since dynamic content has been added
            self.relisten();

        })


        await $(".renderBtn").off("click").on("click", async function () {
            // listen to the edit and delete button


            let category = $(this).attr("category");
            let name = $(this).attr("name");
            let obj = self.executableHistory[name];
            let toolBox = Object.keys(obj)[0];
            let toolAction = obj[toolBox]["name"];

            if (category == "edit") {
                console.log("Editing the action, switched to edit mode", name);
                self.editMode = {};
                self.editMode.name = name;
                self.editMode.index = $(this).attr("index");


                console.log("The object to edit", obj);

                // check if we have a clean slate or a staged slate before allowing edit. 
                //a clean state means we dont have any edit on the current action that we might be overwriting

                if (self.addChainSlate == "working") {
                    let prompt = await self.executableManager.renderEngine.popPrompt(
                        {
                            title: "Overwrite Action Board?",
                            note: "You have an open action that is yet to be  added to the executable list, editing an action from history would overwrite your current data on the action board, are you sure you want to edit this action on history and loose your progress on the action baord?"
                        });

                    if (prompt != "confirmed") {
                        return
                    }
                }

                //  render the toolBox
                await $("#tool-box").val(toolBox).change();

                //value of toolAction in this context is the selected option, while normally we would use the value of the option to load and prepare the action board. we would have to find the value of the option and use it to load the action board

                //  render the toolAction
                let selected = await $(`#tool-action option:contains(${toolAction})`).val();
                await $("#tool-action").val(selected).change();

                let actions = obj[toolBox].requirement;
                let secondaryActions = obj[toolBox].secondary;


                for (const key in actions) {
                    if (actions.hasOwnProperty(key)) {
                        let selector = `.tool-input[category="primary"][name="${key}"]`;
                        let input = await self.waitForElement(selector)
                        $(input).val(actions[key]);
                    }
                }

                for (const key in secondaryActions) {
                    if (secondaryActions.hasOwnProperty(key)) {
                        let selector = `.tool-input[category="secondary"][name="${key}"]`;
                        let input = await self.waitForElement(selector)
                        $(input).val(actions[key]);
                    }
                }

                // remove the action from the history
                delete self.executableHistory[name];

                // re listen to events since dynamic content has been added
                self.relisten();

            }
            if (category == "delete") {
                console.log("Deleting the action", name);
                // remove the action from the history
                delete self.executableHistory[name];

                // re listen to events since dynamic content has been added
                self.relisten();
            }

        })

        await $('.tool-input').off("change").on("change", async function () {
            self.addChainSlate = "working";
            console.log("working on the action board");
        });







    }

}