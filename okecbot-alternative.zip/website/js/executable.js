$(document).ready(async function () {

    //apiKey 
    var apiKey = (await $.get("login/key.json")).apiKey;
    var executable = null;
    let loadingIConDiv = "<div id='loadingIConDiv' class='p-3 text-center' > <img src='images/loading.gif' /> </div>"

    async function popMsg(msg, def = "") {
        // show a custom pop up denoting a challenege / Error encountered

        // update the pop ip title 
        $('#buildLogHeader').text(msg.title);

        // lets update the message 
        $('#buildLogMsg').html(msg.message);

        // pop up the notification 
        $('#buildLog').modal({
            backdrop: 'static',
            keyboard: false
        });

        if (msg.size == "small") {
            $("#popSize").removeClass("modal-lg");
        } else {
            $("#popSize").removeClass("modal-lg")
            $("#popSize").addClass("modal-lg")
        }

    }


    await $.post(`https://okecbot.com/api/index.php?key=${apiKey}&showActivities`).then(async function (data) {
        $("#loadingIConDiv").remove();
        $("#execute-container").append(`<select category="secondary" class="custom-select mt-3" id="activityChain" ></select>`);
        // lets make a select option for it
        data["json"].forEach((element, index) => {
            $("#activityChain").append(`<option value="tit-${index}" > ${element.title} </option>`)
        });

        // update executable
        executable = data["json"];

        let style = ` 
                <div class="d-flex mt-2  justify-content-around">
                    <div category="orderly"  class="cursorEnable exec-btn bg-white img45" style="margin-right: 20px;">
                        <img src="images/orderly.png" id="" class="controlBtn " style="float: left; margin-right: 10px; transform:rotate(90deg)" />
                        <small style="display: block;">Each bot should execute the activites accordingly, from top to bottom</small>
                    </div>


                    <div category="randomly" class="cursorEnable exec-btn bg-white img45" style="margin-right: 20px; ">
                        <img src="images/randomly.png" id="" class="controlBtn " style="float: left;; margin-right: 10px;" />
                        <small style="display: block;">Each bot should execute activites randomly in no particular order</small>
                    </div>
                </div>`;


        $("#executable_prompt").html(style)


        // add listener to post the exec on the checkedList
        $(".exec-btn").click(async function () {

            let flow = $(this).attr("category")

            let activities = executable[parseInt($("#activityChain").val().replace("tit-",""))]

            let config = {
                promptTitle: ` <span class='ml-5'> Run executable (${activities["title"]}) </span>`,
                feedBack: `preparing to command bots`,
                actionState: "comamanding",
                endPoint: `http://localhost:3000/execute_botName`,
                endPoint_Fail_Text: "Failed to command bot",
                action: "activity_chain",
                compliment_data: JSON.parse(activities["data"])
            }

            console.log(config)

            let prompt = await botM.promptAction(config);

        })


    })


    $("#executable").click(async () => {

        let index = $("#activityChain").val();
        if ((executable != null) && (index != undefined)) {

            // since the vale has been updated post it to the server to execute


            let preparedData = {
                "mission": "activity-chain",
                "activity": JSON.parse(executable[`${index.split('-')[1]}`].data),
                "orderly": true
            }

            console.log(preparedData)

            await $.ajax({
                url: `http://localhost:3000/controller`,
                contentType: 'application/json',
                data: JSON.stringify(preparedData), method: "POST", dataType: "json"
            }).then(() => {

            }
            );

        }

    })

})