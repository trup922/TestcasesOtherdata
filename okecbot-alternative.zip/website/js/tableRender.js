export class renderData {

    constructor(data) {

        this.currentPage = data.currentPage;
        this.itemsPerPage = data.itemsPerPage;
        this.botEngine = data.botEngine;
    }

    addProp(data) {
        this[data.key] = data.val;
    }

    alert(){
        alert("sdfds")
    }

    async popPrompt(msg) {
        // show a custom pop up denoting a challenege / Error encountered

        return new Promise((resolve, reject) => {

            // show prompt footer
            $("#promptFooter").show();

            // update the pop ip title 
            $('#buildLogHeader').html(msg.title);

            // lets update the message 
            $('#buildLogMsg').html(msg.note);

            if (msg.table != undefined) {
                this.returnTable(msg.table)
            }

            // pop up the notification 
            $('#buildLog').modal({
                backdrop: 'static',
                keyboard: false
            });

            $("#confirmPrompt").off("click").on("click", function () {
                $('#buildLog').modal('hide')
                resolve("confirmed")
            })
            $("#abortPrompt").off("click").on("click", function () {
                $('#buildLog').modal('hide')
                resolve("abort")
            })

        })
    }

    popInfo(info) {

        // show/hide prompt footer
        if (info.promptFooter) {
             $("#promptFooter").show(); } else { $("#promptFooter").hide(); }

        // update the pop ip title 
        $('#buildLogHeader').html(info.title);

        // lets update the message 
        $('#buildLogMsg').html(info.message);

        if (info.table != undefined) {
            this.returnTable(info.table)
        }

        if ((info.promptFooter) && (typeof info.promptFooter == 'string')) {
            $("#confirmPrompt").html(info.promptFooter)

        }
        // pop up the notification 
        $('#buildLog').modal({
            backdrop: 'static',
            keyboard: false
        });
    }

    returnTable(dataObject) {
        /*
            This function would receive an object and make a table with the object keys
            when done, it would return back the table and the requster can then append
            the table to where ever they want
        */

        return new Promise((resolve) => {

            // Create a container for the table and set its position to relative
            let tableContainer = document.createElement('div');
            tableContainer.className = 'table-container';
            tableContainer.style.position = 'relative';

            // Create the table with Bootstrap classes
            let table = document.createElement('table');
            table.className = 'table table-light table-striped table-hover'; // Bootstrap classes
            table.id = "popTable";

            // Create the header row
            let thead = table.createTHead();
            let headerRow = thead.insertRow();
            headerRow.className = 'thead-dark'; // Bootstrap class for dark header

            // Extract keys for table headers
            let headers = Object.keys(dataObject);
            headers.forEach((header) => {
                let th = document.createElement('th');
                th.textContent = header;
                headerRow.appendChild(th);
            });

            // Append the table to the container
            tableContainer.appendChild(table);

            // Append the table container to #buildLogMsg
            $(`#buildLogMsg`).append(tableContainer);

            // Find the longest array to determine the number of rows
            let rowCount = Math.max(
                ...Object.values(dataObject).map((arr) => arr.length)
            );

            // Function to add a row
            function addRow(i) {
                let row = table.insertRow();
                row.className = 'table-light'; // Bootstrap class for light rows

                headers.forEach((header) => {
                    let cell = row.insertCell();
                    let cellData = dataObject[header][i];
                    if (cellData !== undefined) {
                        cell.textContent = cellData;
                    }
                });

                // Animate the row
                $(row).hide().fadeIn(300, function () {
                    // Scroll the table container to the bottom after the row is added
                    tableContainer.scrollTop = tableContainer.scrollHeight;

                    // Resolve the Promise when the last row is added
                    if (i === rowCount - 1) {
                        resolve();
                    }
                });
            }

            // Sequentially add each row with a delay
            for (let i = 0; i < rowCount; i++) {
                setTimeout(() => addRow(i), i * 100); // Adjust the timing as needed
            }
        });
    }

    appendTable(dataObject) {
        return new Promise((resolve, reject) => {
            let table = $("#popTable")[0];

            if (!table) {
                reject('Table #popTable not found');
                return;
            }

            let row = table.insertRow();
            row.className = 'table-light'; // Bootstrap class for light rows

            Object.keys(dataObject).forEach((header) => {
                let cell = row.insertCell();
                let cellData = dataObject[header][0];
                if (cellData !== undefined) {
                    cell.textContent = cellData;
                }
            });

            // Scroll the table container to the bottom after the row is added
            $("#buildLogMsg")[0].scrollTop = $("#buildLogMsg")[0].scrollHeight;

            resolve();
        });
    }

    update_Last_Cell(dataObject) {
        /*
        This method would  select the last cell node of the table 
        that was popped up. usually the last cell has a text 'informing server'
            this method would receive an object containing a text color, a text
        and this text would be used to update the last cell.

        Example of usage: this.update_Lat_Cell({
            "text":dataObject.text,
            "bootstrap_class": "text-success"
        })
        */

        // Select the last cell of the table
        var lastCell = $("#popTable tr:last td:last");

        // Update the text of the last cell
        lastCell.text(dataObject.text);

        // Remove all previous classes from the last cell
        lastCell.removeClass();

        // Add the new class to the last cell
        lastCell.addClass(dataObject.bootstrap_class);
    }


    listBotTable(filtered, botEngine = this.botEngine) {

        // empty the container
        $("#dataBody").empty();

        // clear all check
        $("#checkAll").prop("checked", false)




        let start = (this.currentPage - 1) * this.itemsPerPage;
        let end = start + this.itemsPerPage;

        for (let i = start; i < end && i < filtered.length; i++) {
            let personality = JSON.parse(`${filtered[i].personality}`);


            var proxy = {
                Server: "localNetwork",
                Username: "---"
            }

            if (personality.Location != "NULL") {
                proxy.Server = personality.Location.proxyServer;
                proxy.Username = personality.Location.proxyUsername;
            }

            let checked = this.botEngine.checkedList.includes(filtered[i].fullname) ? "checked" : "";

            let row = `<tr id="row-${filtered[i].fullname}" >
            <td> <div class="custom-control custom-checkbox"> <input class="form-check-input bot-presence" type="checkbox" ${checked} name="${filtered[i].fullname}" id="bot-${filtered[i].fullname}" required> </div> </td>
            <td>${filtered[i].fullname}</td>
            <td>${personality.Device.deviceName}</td>
            <td>${personality.Device.timeZone}</td>
            <td>${proxy.Username}</td>
            <td>${proxy.Server}</td>
            <td>${filtered[i].lastUsed}</td>
        </tr>`;


            $("#dataBody").append(row);

        }

        // Add a change event handler for the header checkbox
        $("#checkAll").change(function () {
            const isChecked = $(this).prop("checked");
            $(".bot-presence").prop("checked", isChecked);

            // now we have checked all on this current list lets move over to update them on the upget
            $(".bot-presence").each(function () {
                // reupdate the ticket list array each time a change is done
                if ($(this).is(':checked')) {
                    // If checked, add the 'name' attribute to the array
                    if (!botEngine.checkedList.includes($(this).attr('name'))) {
                        botEngine.checkedList.push($(this).attr('name'));
                    }
                } else {
                    // If not checked, remove the 'name' from the array
                    const index = botEngine.checkedList.indexOf($(this).attr('name'));
                    if (index > -1) {
                        botEngine.checkedList.splice(index, 1);
                    }
                }

                //botEngine.checkedList)


            });
        });




    }

    async renderPagination(filtered, botEngine = this.botEngine) {

        return new Promise((resolve) => {
            $("#pagination").empty();
            let totalPages = Math.ceil(filtered.length / this.itemsPerPage);

            for (let i = 1; i <= totalPages; i++) {
                let pageItem = `<li class="page-item ${i === this.currentPage ? 'active' : ''}"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
                $("#pagination").append(pageItem);
            }

            $(".page-link").click(async function (e) {

                /* since we would like to speicific element by class that was clicked, i would temporary stash the value of this 
                inside the variable outside, although using arrow function would have save me the stress because arrow function
                use the this value of the external function but how then are we gonna know how clicked it? at the moment stashing
                the variable into outside sounds smart 
                */
                e.preventDefault();
                botEngine.renderEngine.currentPage = $(this).data("page");

                if (botEngine.botList === "active") {
                    await botEngine.render(botEngine.botStatus.runningBots);
                } else {
                    if (botEngine.filteredList != null) {
                        await botEngine.render(botEngine.filteredList);
                    } else {
                        await botEngine.render(botEngine.botStatus.offBots);
                    }
                }
            });

            $(".bot-presence").change(function () {
                // reupdate the ticket list array each time a change is done
                if ($(this).is(':checked')) {
                    // If checked, add the 'name' attribute to the array
                    if (!botEngine.checkedList.includes($(this).attr('name'))) {
                        botEngine.checkedList.push($(this).attr('name'));
                    }
                } else {
                    // If not checked, remove the 'name' from the array
                    const index = botEngine.checkedList.indexOf($(this).attr('name'));
                    if (index > -1) {
                        botEngine.checkedList.splice(index, 1);
                    }
                }

                // console.log(botEngine.checkedList)


            });

            resolve();

        });
    }



}