import { botManager } from './botManager.js';
import { renderExecutable } from './render-Executable.js';
/*

    This class would be used on the create executable page to assit users in making executable activities.
    This class would validate the inputs and also make the necessary calls to the server to create the executable activities.
    This class would also be responsible for rendering the data on the page.

*/

export class executableManager {

    constructor() {
        this.executableHistory = new renderExecutable(this);
        this.apiKey = null;
        this.serverProcessTxt = '<div class="p-3 text-center"> Processing your request with okecbot servers... <img src="images/loading.gif" /> </div>';

        // botManaging tools
        this.botEngine = new botManager();
        this.renderEngine = this.botEngine.renderEngine;

        // Executable capabilities and tools
        this.toolPack = [];

        // activity history
        this.serverExecutables = [];

        // render Executable

        this.main();
    }

    async main() {
        this.apiKey = (await $.get("login/key.json")).apiKey;
        this.toolIcons = await $.getJSON("component/json/icons.json");
        this.control_Button();
        await this.loadToolPack();
        await this.update_Tool_Box_Img();
        this.load_Primary_Actions();
        this.load_Primary_Inputs();
        this.load_Secondary_Input();
        await this.reListen();
        this.executableHistory.relisten();
    }

    async update_Tool_Box_Img() {

        // we check the tool pack active and then state the image
        let toolPack = $("#tool-box").val();
        let imgSrc = await this.toolIcons[toolPack];
        $("#tool-box-img").attr("src", imgSrc);
    }

    async reListen() {
        /*
            This method would be use to unset all event listeners and re-listen to the events. 
            This is because new items might have been added to tbe dom.
        */
        let self = this;

        await self.update_Tool_Box_Img(); // sync Image of tool box 

        await $("#tool-box").off("change").on("change", async function () {



                // we also need to render the tools for the selected tool pack
                self.load_Primary_Actions();
                self.load_Primary_Inputs();
                self.load_Secondary_Input();

                self.update_Tool_Box_Img(); // sync Image of tool box 

                // relisten to the new inputs on the history side
                self.executableHistory.relisten();


        })

        await $("#tool-action").off("change").on("change", async function () {
                self.load_Primary_Inputs();
                self.load_Secondary_Input();

                // relisten to the new inputs on the history side
                self.executableHistory.relisten();

        })
    }

    control_Button() {
        /*
         Control button class on this system is used to convert any dom element into an action trigger.
         When a dom element with control button class is clicked that element is reviewed and an action is taken.
         */

        let self = this;

        $(".controlBtn").off("click").on("click", async function () {
            let task = $(this).attr("category");
            let query = $(this).attr("name");
            let apiKey = self.apiKey;

            switch (task) {
                case "saveChain":
                    self.renderEngine.popInfo({
                        title: "Save chain of actions as an executable",
                        message: `
                        <div id="saveActDiv" class="d-flex justify-content-between" > 
                            <input id="activityName" type="text" class="form-control w-75 " placeholder="Executable Name">
                            <button id="saveActivity" category="saveActivity" class="bg-secondary btn controlBtn text-white" > Save </button>
                        </div> `
                    })
                    self.control_Button();
                    break;

                case "saveActivity":

                    let executableName = $("#activityName").val();
                    let executableHistory = self.executableHistory.executableHistory;
                    //Store the data on okecbot server
                    $('#buildLogMsg').html(self.serverProcessTxt);
                    await $.ajax({
                        method: "POST",
                        url: `https://okecbot.com/api/index.php?key=${apiKey}&addActivity&activityTitle=${executableName}`,
                        data: JSON.stringify(executableHistory),
                        contentType: "application/json",
                        dataType: "json",
                        success: function (response) {
                            if (response.status == "success") {

                                let template = `   <div class="p-3 text-center">  Successfully saved your activities on okecbot server. </br>
                                                        <img src="images/success.gif" />
                                                    </div> 
                                                `;


                                // lets update the success message 
                                $('#buildLogMsg').html(template);

                            } else {

                                let template = `
                                                <div class="p-3 text-center">
                                                    Error .! couldn's save the activity to okecbot servere:: ${response.body}
                                                    </br>
                                                    <img src="images/failed.gif" />
                                                </div>
                                            `;


                                // lets update the failure message 
                                $('#buildLogMsg').html(template);

                            }
                        },
                        error: function (error) {
                            console.log(" Couldnt send ! ")
                        }
                    });

                    self.control_Button();
                    break;

                case "edit-executable":
                    // we would use the render for this
                    let editExec = JSON.parse(self.serverExecutables[query]["data"]);
                    // overwrite the executableHistory object
                    self.executableHistory.executableHistory = editExec;
                    console.log(" The server exec", editExec)
                    //relisten and render the updated executables
                    self.executableHistory.relisten();

                    //change the icon(img src) into something to show it is been worked on
                    $(this).attr("src","images/editMode.gif")

                    // now lets relisten the control button
                    self.control_Button();
                    break;

                case "viewChains":
                    $('#buildLog').modal('show');
                    $('#buildLogMsg').html(self.serverProcessTxt);
                    // query okecbot and get the saved activities
                    await $.ajax({
                        method: "POST",
                        url: `https://okecbot.com/api/index.php?key=${apiKey}&showActivities`,
                        contentType: "application/json",
                        dataType: "json",
                        success: function (response) {
                            if (response.status == "success") {

                                let records = response.json;
                                let memo = "";

                                //save it in memory here
                                self.serverExecutables = records;
                                console.log("server executables saved in memory")

                                records.forEach((element, index) => {
                                    memo += ` <tr> <td> <img category="edit-executable" name="${index}" class="controlBtn cursor" width="35" src="images/edit-icon.png" /> </td> <td> ${element.title} </td> <td> ${element.created} </td> <td> ${element.execution_count} </td> <td> <img width="20" class="controlBtn cursor" category="deleteChain" name="${element.title}" src="images/delete.png" /> </td> </tr> `;
                                });

                                self.renderEngine.popInfo({
                                    title: "Saved chained activities",
                                    message: `
                                            <div class="p-3 w-100 text-center">

                                                <table  class="table table-striped mx-auto bg-light ">
                                                    <thead class="thead-dark">
                                                        <tr>
                                                            <th>  </th>
                                                            <th> Executable Name </th>
                                                            <th> Created </th>
                                                            <th> Execution count </th>
                                                            <th>  </th>
                                                        </tr>
                                                    </thead>
                                                    ${memo}

                                                </table>

                                            </div>
                                    `
                                })

                            } else {
                                self.renderEngine.popInfo({
                                    title: "loading activities failed!",
                                    message: `

                                            <div class="p-3 text-center">

                                                Error .! couldn's load the activity on okecbot server, error code:: ${response.error}
                                                </br>
                                                <img src="images/failed.gif" />

                                            </div>

                                            `})


                            }
                        },
                        error: function (error) {
                            console.log(" Couldnt send ! ")
                        }
                    });

                    self.control_Button();
                    break;
                case "deleteChain":
                    // lets send the title of the chain to the server so it deletes it
                    $('#buildLogMsg').html(self.serverProcessTxt);
                    // query okecbot and get the saved activities
                    await $.ajax({
                        method: "POST",
                        url: `https://okecbot.com/api/index.php?key=${apiKey}&deleteActivity&activityTitle=${query}`,
                        contentType: "application/json",
                        dataType: "json",
                        success: function (response) {
                            if (response.status == "success") {

                                self.renderEngine.popInfo({
                                    title: "Deleted",
                                    message: `
                                            <div class="p-3 w-100 text-center">

                                                <p> The activity chain was deleted suucessffully </p>
                                                <p> <img src="images/success.gif" /> </p>

                                            </div>
                                    `
                                })

                            } else {
                                self.renderEngine.popInfo({
                                    title: "loading activities failed!",
                                    message: `

                                            <div class="p-3 text-center">

                                                Error .! couldn's delete the activity on okecbot server:: ${response.error}
                                                </br>
                                                <img src="images/failed.gif" />

                                            </div>

                                            `})


                            }
                        },
                        error: function (error) {
                            console.log(" Couldnt send ! ")
                        }
                    });
                    self.control_Button();
                    break;

                case "primary-action":
                    // let us make sure the right button is visible and the right div too!.
                    $("#action").attr("category", "secondary-action");
                    $("#action").attr("src", "images/secondary-action.png")
                    $("#secondary-action").show()
                    $("#primary-action").hide()
                    self.control_Button();
                    break;
                case "secondary-action":
                    // let us make sure the right button is visible and the right div too!.
                    $("#action").attr("category", "primary-action");
                    $("#action").attr("src", "images/primary-action.png")
                    $("#primary-action").show()
                    $("#secondary-action").hide()
                    self.control_Button();
                    break;
                default:
                    self.control_Button();
                    break;
            }
        })

    }

    async loadToolPack() {
        /*
            This tool renders the tool pack on the page. 
            With this tool pack, the user can select the tools to be used in the executable activity.
        */

        let self = this;

        await $.ajax({
            method: "POST",
            url: `controller`,
            data: JSON.stringify({ mission: "controls-info" }),
            contentType: "application/json",
            dataType: "json",
            success: async function (response) {
                self.toolPack = response;
            }
        });

        // loop through and append the tools to the toll box selection
        for (let key of Object.keys(self.toolPack)) {
            //append the tools to the selectio so users can select of it.
            $('#tool-box').append(`<option value="${key}" > ${key} tools </option> `);
        }

        return "done";

    }

    async load_Primary_Actions() {

        let self = this;

        let tool = await $('#tool-box').val()
        tool = self.toolPack[tool];
        $('#tool-action').empty();
        for (let key of Object.keys(tool)) {
            //append the tools to the selectio so users can select of it.
            $('#tool-action').append(`<option value="${key}" > ${tool[key].name}  </option> `);
        }
    }

    async load_Primary_Inputs() {

        let self = this;

        $("#primary-req").empty();
        let tool = await $('#tool-box').val();
        let toolAction = await $('#tool-action').val()
        let inputs = self.toolPack[tool][toolAction].requirement;

        for (let key of Object.keys(inputs)) {
            let prop = key;
            let dataType = inputs[key];

            $('#primary-req').append(self.return_Input(dataType, prop, "primary"));
        }
    }

    return_Input(dataType, prop, category) {

        switch (dataType[0]) {
            case "input":
                return ` 
                
                <div class="input-group mb-3">
                    <input category="${category}" name="${prop}" type="text" class="form-control tool-input control-info" placeholder="${dataType[1]}">
                    <div class="input-group-append">
                    <span class="input-group-text">${prop}</span>
                    </div>
                </div>`

                break;
            case "ask":
                return `
                <div class="border mt-3 mb-3 pt-3 border-secondary" >
                    
                    <h6 class="text-center">${dataType[1]}</h6>
                    <ul> 
                        <li> <input category="${category}" class="ask-input tool-input control-info" type="text"  name="${prop}"> ${prop}  </div>                      
                        
                    </ul>
                </div>
                `;
                break;

            case "textarea":
                return `  <div class="form-group">
                                <label class="" for="txt-${prop}">${dataType[1]} :</label>
                                <textarea category="${category}" class="form-control tool-input control-info" name="${prop}" id="txt-${prop}" rows="4"></textarea>
                        </div>`;
                break
            // You can have any number of case statements
            default:
            // Code to execute if expression doesn't match any case
        }
    }

    async load_Secondary_Input() {
        let self = this;

        $("#secondary-req").empty();
        let tool = await $('#tool-box').val();
        let toolAction = await $('#tool-action').val()
        let inputs = self.toolPack[tool][toolAction].secondary;

        for (let key of Object.keys(inputs)) {
            let prop = key;
            let dataType = inputs[key];

            $('#secondary-req').append(self.return_Input(dataType, prop, "secondary"));
        }

    }

}