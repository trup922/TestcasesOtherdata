/*
    This class would be use to validate the input provided by the user and send back response to the user.
    We would validate everything from a valid url to dataTypes entered vs what is expected
*/

export class validateExecutable {

    constructor(renderExecutable) {
        console.log("validateExecutable class created")
        this.renderExecManager = renderExecutable;
    }

    async validate(obj) {

        let received = { ...obj };
        received["mission"] = "validate-input";

        //sending the data received! so as to know if it has been validated or
        let inputFeedback = await $.ajax({
            url: `http://localhost:3000/controller`,
            method: "POST",
            dataType: "json",
            contentType: 'application/json',
            data: JSON.stringify(received),
        });

        if (inputFeedback.status == false) {
            this.renderExecManager.executableManager.renderEngine.popPrompt({
                title: "Validation Failed",
                note: `${inputFeedback.message}`
            })
            return false;
        } else {
            return true;
        }

    }



}