import { renderData } from './tableRender.js';
// Define a class to manage the bot-related functionalities
export class botManager {

    constructor() {
        console.log(" Bot manager initiated !;")
        // Initialize state variables
        this.botList = "inActive";
        this.botStatus = {
            runningBots: ['notUpdated'],
            offBots: ['notUpdated']
        };
        this.apiKey = null;
        this.personalities = 'notLoaded';

        // renderEngine
        this.renderEngine = new renderData({
            currentPage: 1,
            itemsPerPage: 12,
            botEngine: this
        });

        this.filterConfig = {};
        this.filteredList = null;
        this.checkedList = [];

        // initaite this object,load the necessary data
        this.init()
    }

    talk() {
        alert(" I am the bot manager ")
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    createTable(dataObject) {
        // Create table headers
        let table = $("<table>").attr("id", "popTable").addClass("table table-light table-striped table-hover");
        let thead = $("<thead>");
        let headerRow = $("<tr>");
        Object.keys(dataObject).forEach((header) => {
            headerRow.append($("<th>").text(header));
        });
        headerRow.addClass('thead-dark'); // Use addClass instead of className
        thead.append(headerRow);
        table.append(thead);

        // Append table to a container
        $("#buildLogMsg").append(table);
    }


    async promptAction(config) {
        $("#abortPrompt").hide()

        if (this.checkedList.length < 1) return 0
        // Prompt the user to accept delete or abort the process
        let payload = {
            title: config.promptTitle,
            note: " ",
            table: {
                "Name": this.checkedList,
                "Device": this.checkedList.map((item) => this.getBotInfo(item).deviceName),
                "TimeZone": this.checkedList.map((item) => this.getBotInfo(item).timeZone),
            }

        }

        let prompt = await this.renderEngine.popPrompt(payload)
        if (prompt != "confirmed") return 0
        $('#buildLog').modal('hide');
        $("#loadingData").modal("show")
        await this.sleep(this.getRandomInt(3000, 5000));
        $("#loadingData").modal("hide")

        // from here, we would start a live update showing the status of the delete

        // lets update the message 
        $('#buildLogHeader').empty();
        $('#buildLogMsg').empty();
        // pop up the notification 
        // lets update the message 
        $('#buildLogHeader').html(config.feedBack);
        $('#buildLog').modal({
            backdrop: 'static',
            keyboard: false
        });
        //remove the footer, where prompt is
        $("#promptFooter").hide();
        await this.sleep(3000);


        // Create the table
        this.createTable({ "Name": null, "Device": null, "FeedBaack": null });

        // Create an array to store the names of the bots that were successfully deleted
        let processedBots = [];

        // Store the total number of bots to be deleted
        let totalBots = this.checkedList.length;

        // Iterate through the checkedList using a while loop
        while (this.checkedList.length > 0) {
            // Use the first bot in the list
            let bot = this.checkedList[0];

            // Calculate the current index
            let currentIndex = totalBots - this.checkedList.length + 1;

            // Update the message
            $('#buildLogHeader').html(`<span> ${config.actionState} ${currentIndex} of ${totalBots} </span>`);
            await this.renderEngine.appendTable({
                "Name": [bot],
                "Device": [this.getBotInfo(bot).deviceName],
                "Status": ['informing server..'],
            });

            let browserVisibility = $("#hide-show").attr("headless");

            // if prompt doesnt have a compliment_Data create one, else use prompts own
            let compliment_data = [];
            if (config.compliment_data == undefined) {
                compliment_data = {
                    personality: this.getBotInfo(bot, "all"),
                    headless: browserVisibility
                }
            }else{
                compliment_data = config.compliment_data;
            }


            try {
                const response = await $.ajax({
                    url: `${config.endPoint}`,
                    method: "POST",
                    dataType: "json",
                    contentType: 'application/json',
                    data: JSON.stringify({ botName: bot, action: config.action, compliment_data: compliment_data }),
                });

                console.log(response)

                if (response.status == "success") {
                    this.renderEngine.update_Last_Cell({
                        text: response.body,
                        bootstrap_class: "text-success"
                    });

                    // Add the bot name to the processedBots array
                    processedBots.push(bot);
                } else {
                    this.renderEngine.update_Last_Cell({
                        text: config.endPoint_Fail_Text,
                        bootstrap_class: "text-danger"
                    });
                }
            } catch (error) {
                console.error(error);
                this.renderEngine.update_Last_Cell({
                    text: "Error occurred while taking this action",
                    bootstrap_class: "text-danger"
                });
            }

            // Remove the bot from the checked list
            this.checkedList.shift();
        }

        // After all AJAX requests are completed, update the UI and the lists
        processedBots.forEach((botName) => {

            if (config.action != "exec") {
                // Remove the row from the table
                $(`#row-${botName}`).remove();

            }

            // Remove the bot from the personality list
            if (this.personality && config.action == "delete") {
                this.personality = this.personality.filter(bot => bot !== botName);
            }

            // Remove the bot from the offBots list
            if (this.offBots && config.action != "de-activate") {
                this.offBots = this.offBots.filter(bot => bot !== botName);
            }
        });

        $("#abortPrompt").fadeIn('slow')


    }

    getBotInfo(botName, all = false) {

        let personality = [];
        // run a lopp across the personalities saved already
        // and return an object containing the details on personality
        this.personalities.forEach(function (item) {
            if (item.fullname == botName) {
                personality = item.personality
            }
        })

        if (all == "all") {
            return JSON.parse(personality);
        }

        return JSON.parse(personality).Device;
    }

    async renderFilter() {
        //console.log(" rendering table with the filter applied",this.filterConfig)
        // Get the selected option
        let selectedBotName = $("#botNames").val();

        let rawData = [...this.botStatus.offBots];

        // Create a regular expression to match the selected bot name with any numeric suffix
        const regex = new RegExp(`^${selectedBotName}(-\\d+)?$`);

        // Filter rawData to include only items that match the regex
        let filtered = rawData.filter(item => regex.test(item.fullname));

        $.each(this.filterConfig[selectedBotName], (key, index) => {

            if (this.filterConfig[selectedBotName][key] == false) {

                $(`[catalogue='${key}']`).addClass('false')

                filtered = filtered.filter(item => {
                    let check = JSON.parse(item.personality).Device.userAgent.includes(key);
                    if (check) { return false } else { return true }
                })
            }

        });

        if (this.botList != "active") {

            this.filteredList = filtered.sort((a, b) => a.fullname.localeCompare(b.fullname)); // sort the array by names
            this.renderEngine.listBotTable(this.filteredList);
            await this.renderEngine.renderPagination(this.filteredList);
            this.countDevices(this.filteredList, false)
        } else {

            this.renderEngine.listBotTable(this.botStatus.runningBots);
            await this.renderEngine.renderPagination(this.botStatus.runningBots);
            this.countDevices(this.botStatus.runningBots, false)

        }


    }


    async setupFilter() {
        await this.filterBotName().then((names) => {

            names.forEach(item => {

                $("#botNames").append(`<option value="${item}" > ${item} </option>`)
                this.filterConfig[item] = {
                    iPhone: true,
                    Android: true,
                    Windows: true,
                    Mac: true
                }
            })

        })

        // now the option has been loaded, now count the devices and display them.
        // lets listen to the devices
        $("#botNames").change(() => {
            $("#discipline").remove();
            this.renderEngine.currentPage = 1; //reset the page so it doesnt disturb our new selection
            $(".filterOs").removeClass("false")
            this.renderFilter();
        })

    }

    filterBotName() {
        // this function would filter the names of the personalities
        // it will remove the 001,002,003... and push all the names into an array and then 
        // remake a new array with only unique names meaning repitition of names are not done on the new array
        // this unique names array would then saved in the filterConfig object followed by the allowed operatinng systems
        let rawData = [...this.botStatus.offBots];

        // Use a Set to store unique names
        let uniqueNamesSet = new Set();

        // Regular expression to match the numeric suffix
        const regex = /-\d+$/;

        // Iterate over rawData to extract and clean names
        rawData.forEach(item => {
            const cleanName = item.fullname.replace(regex, ""); // Remove the numeric suffix
            uniqueNamesSet.add(cleanName); // Add to the set, which keeps only unique values
        });

        // Convert the set back to an array
        let uniqueNames = Array.from(uniqueNamesSet);

        return Promise.resolve(uniqueNames)
    }

    async init() {
        await this.loadData();
        await this.updateStatusBots()
        this.botList == "inActive" ? this.render(this.botStatus.offBots) : this.render(this.botStatus.runningBots)
        await this.setupFilter()
        $("#loadingData").modal('hide');

    }

    async loadData() {
        return new Promise(async (resolve) => {
            this.apiKey = (await $.get("login/key.json")).apiKey;
            try {
                let response = await $.ajax({ url: `https://okecbot.com/api/index.php?key=${this.apiKey}&request=personality`, method: "GET", dataType: "json" });
                this.personalities = response;
                resolve();

            } catch (error) {
                console.error("Error loading data:", error);
            }
        });
    }

    checkedBots() {
        // Initialize an empty array to store the names of checked checkboxes
        let checkedNames = [];

        // Use jQuery to select all checkboxes with the class .bot-presence
        $('.bot-presence').each(function () {
            // Check if the checkbox is checked
            if ($(this).is(':checked')) {
                // If checked, add the 'name' attribute to the array
                checkedNames.push($(this).attr('name'));
            }
        });

        // Return a Promise that resolves with the checkedNames array
        return Promise.resolve(checkedNames);
    }

    countDevices(filtered, target) {
        let deviceCounts = { iPhone: 0, Android: 0, Windows: 0, Mac: 0 };


        filtered.forEach(item => {
            const userAgent = JSON.parse(item.personality).Device.userAgent;

            if (userAgent.includes("iPhone")) {
                deviceCounts.iPhone++;
            } else if (userAgent.includes("Android")) {
                deviceCounts.Android++;
            }
            else if (userAgent.includes("Win")) {
                deviceCounts.Windows++;

            } else if (userAgent.includes("Mac")) {
                deviceCounts.Mac++;
            }
        });

        let sum = Object.values(deviceCounts).reduce((a, b) => a + b);

        if (target == undefined) {
            $('#iphoneCount').text(deviceCounts.iPhone)
            $('#androidCount').text(deviceCounts.Android)
            $('#winCount').text(deviceCounts.Windows)
            $('#macCount').text(deviceCounts.Mac)
            $('#activeBrowsers').text(sum)
        } else {
            $('#filteredIphoneCount').text(deviceCounts.iPhone)
            $('#filteredAndroidCount').text(deviceCounts.Android)
            $('#filteredWinCount').text(deviceCounts.Windows)
            $('#filteredMacCount').text(deviceCounts.Mac)
        }
    }

    async updateStatusBots() {

        return new Promise(async resolve => {

            let fullData = [...this.personalities];
            let fileNames = fullData.map(value => value.fullname);
            let on = [];
            let off = [];

            // Use Promise.all() to wait for all AJAX requests to complete
            await Promise.all(fileNames.map(async (fName, index) => {
                try {
                    // Post the name to the isFilerunning endpoint to check if the fileName is currently running
                    const response = await $.ajax({
                        url: `http://localhost:3000/isRunning`,
                        method: "POST",
                        dataType: "json",
                        contentType: 'application/json',
                        data: JSON.stringify({ botName: fName }),
                    });

                    // Handle the response frotrm the server
                    if (response.status === 'running') {
                        on.push(fullData[index]);
                    } else {
                        off.push(fullData[index]);
                    }
                } catch (error) {
                    // Handle any errors that occur during the request
                    console.error('Error couldnt check if the bot file is running !:', error);
                }
            }));

            // Update statusBots after all requests are complete
            this.botStatus.runningBots = [...on];
            this.botStatus.offBots = [...off];

            resolve();

        });

    }

    async render(filtered) {

        return new Promise(async (resolve) => {


            await this.updateStatusBots();
            this.renderEngine.listBotTable(filtered);

            await this.renderEngine.renderPagination(filtered);
            this.countDevices(filtered)
            this.renderFilter();
            resolve();
        })
    }

    reAssignListeners() {

        // let us state all the listensers we want here 


    }


}