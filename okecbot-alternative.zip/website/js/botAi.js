import { renderData } from './tableRender.js';
export class botAi {

    constructor() {
        console.log(" Bot manager initiated !;")
        // Initialize state variables
        this.botList = "inActive";
        this.botStatus = {
            runningBots: ['notUpdated'],
            offBots: ['notUpdated']
        };
        this.apiKey = null;
        this.personalities = 'notLoaded';
        this.executables = 'notLoaded';

        // renderEngine
        this.renderEngine = new renderData({
            currentPage: 1,
            itemsPerPage: 12,
            botEngine: this
        });

        this.filterConfig = {};
        this.filteredList = null;
        this.checkedList = [];

        // initaite this object,load the necessary data
        this.init()


    }

    activateBotNet() {

        // This method would prepare a botNet for activation

        var botFamily = $("#botFamily").val();
        let botFamily_Device_Brands = this.classifyDevices();
        var executable = $("#executables").val();

        var iphone_limit = $("#iphone-execution-limit").val();
        var android_limit = $("#android-execution-limit").val();
        var mac_limit = $("#mac-execution-limit").val();
        var windows_limit = $("#windows-execution-limit").val();

        var minIphone = $("#min-iphone").val();
        var maxIphone = $("#max-iphone").val();

        var minAndroid = $("#min-android").val();
        var maxAndroid = $("#max-android").val();

        var minMac = $("#min-mac").val();
        var maxMac = $("#max-mac").val();

        var minWindows = $("#min-windows").val();
        var maxWindows = $("#max-windows").val();

        let data = {
            department: "activate",
            compliment_Data: {
                botFamily_Name: botFamily,
                botFamily_Executables: JSON.parse(this.executables[executable]["data"]),
                botFamily_Device_Brands:botFamily_Device_Brands,
                botFamily_Device_Brand_Execute_Limit: {
                    iphone: iphone_limit,
                    android: android_limit,
                    mac: mac_limit,
                    windows: windows_limit
                },
                botFamily_Minimum_Active_Device_Brand: {
                    iphone: minIphone,
                    android: minAndroid,
                    mac: minMac,
                    windows: minWindows
                },
                botFamily_Maximum_Active_Device_Brand: {
                    iphone: maxIphone,
                    android: maxAndroid,
                    mac: maxMac,
                    windows: maxWindows
                },
                botFamily_Repeat_Executable: true
            }
        }

       $.ajax({
            url: `http://localhost:3000/botNet`,
            method: "POST",
            dataType: "json",
            contentType: 'application/json',
            data: JSON.stringify(data),
        }).then((response) => {
            console.log(response)
        })

    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }


    getBotInfo(botName) {

        let personality = [];
        // run a lopp across the personality and return an object containing the details on personality
        this.personalities.forEach(function (item) {
            if (item.fullname == botName) {
                personality = item.personality
            }
        })

        return JSON.parse(personality).Device;
    }

    async renderFilter() {
        //console.log(" rendering table with the filter applied",this.filterConfig)
        // Get the selected option
        let selectedBotName = $("#botFamily").val();

        let rawData = [...this.botStatus.offBots];

        // Create a regular expression to match the selected bot name with any numeric suffix
        const regex = new RegExp(`^${selectedBotName}(-\\d+)?$`);

        // Filter rawData to include only items that match the regex
        let filtered = rawData.filter(item => regex.test(item.fullname));

        $.each(this.filterConfig[selectedBotName], (key, index) => {

            if (this.filterConfig[selectedBotName][key] == false) {

                $(`[catalogue='${key}']`).addClass('false')

                filtered = filtered.filter(item => {
                    let check = JSON.parse(item.personality).Device.userAgent.includes(key);
                    if (check) { return false } else { return true }
                })
            }

        });

        if (this.botList != "active") {

            this.filteredList = filtered.sort((a, b) => a.fullname.localeCompare(b.fullname)); // sort the array by names
            this.renderEngine.listBotTable(this.filteredList);
            await this.renderEngine.renderPagination(this.filteredList);
            this.countDevices(this.filteredList, false)
        } else {

            this.renderEngine.listBotTable(this.botStatus.runningBots);
            await this.renderEngine.renderPagination(this.botStatus.runningBots);
            this.countDevices(this.botStatus.runningBots, false)

        }


    }


    async setupFilter() {
        await this.filterBotName().then((names) => {

            names.forEach(item => {

                $("#botFamily").append(`<option value="${item}" > ${item} </option>`)
                this.filterConfig[item] = {
                    iPhone: true,
                    Android: true,
                    Windows: true,
                    Mac: true
                }
            })

        })

        // now the option has been loaded, now count the devices and display them.
        // lets listen to the devices
        $("#botFamily").change(() => {
            $("#discipline").remove();
            this.renderEngine.currentPage = 1; //reset the page so it doesnt disturb our new selection
            $(".filterOs").removeClass("false")
            this.renderFilter();
        })

    }

    filterBotName() {
        // this function would filter the names of the personalities
        // it will remove the 001,002,003... and push all the names into an array and then 
        // remake a new array with only unique names meaning repitition of names are not done on the new array
        // this unique names array would then saved in the filterConfig object followed by the allowed operatinng systems
        let rawData = [...this.botStatus.offBots];

        // Use a Set to store unique names
        let uniqueNamesSet = new Set();

        // Regular expression to match the numeric suffix
        const regex = /-\d+$/;

        // Iterate over rawData to extract and clean names
        rawData.forEach(item => {
            const cleanName = item.fullname.replace(regex, ""); // Remove the numeric suffix
            uniqueNamesSet.add(cleanName); // Add to the set, which keeps only unique values
        });

        // Convert the set back to an array
        let uniqueNames = Array.from(uniqueNamesSet);

        return Promise.resolve(uniqueNames)
    }

    async init() {
        await this.loadData();
        await this.updateStatusBots()
        this.botList == "inActive" ? this.render(this.botStatus.offBots) : this.render(this.botStatus.runningBots)
        await this.setupFilter()

        let executables = [];

        // load the executables
        await $.post(`https://okecbot.com/api/index.php?key=${this.apiKey}&showActivities`).then(async function (data) {

            $("#execute-container").append(`<select category="secondary" class="custom-select mt-3" id="executable" ></select>`);
            // lets make a select option for it
            data["json"].forEach((element, index) => {
                $("#executables").append(`<option value="${index}" > ${element.title} </option>`)
            });

            // update executable
            executables = data["json"];


        })

        this.executables = executables;

        $("#loadingData").modal('hide');

    }

    async loadData() {
        return new Promise(async (resolve) => {
            this.apiKey = (await $.get("login/key.json")).apiKey;
            try {
                let response = await $.ajax({ url: `https://okecbot.com/api/index.php?key=${this.apiKey}&request=personality`, method: "GET", dataType: "json" });
                this.personalities = response;
                resolve();

            } catch (error) {
                console.error("Error loading data:", error);
            }
        });
    }


    countDevices(filtered, target) {
        let deviceCounts = { iPhone: 0, Android: 0, Windows: 0, Mac: 0 };


        filtered.forEach(item => {
            const userAgent = JSON.parse(item.personality).Device.userAgent;

            if (userAgent.includes("iPhone")) {
                deviceCounts.iPhone++;
            } else if (userAgent.includes("Android")) {
                deviceCounts.Android++;
            }
            else if (userAgent.includes("Win")) {
                deviceCounts.Windows++;

            } else if (userAgent.includes("Mac")) {
                deviceCounts.Mac++;
            }
        });

        let sum = Object.values(deviceCounts).reduce((a, b) => a + b);

        if (target == undefined) {
            $('#iphoneCount').text(deviceCounts.iPhone)
            $('#androidCount').text(deviceCounts.Android)
            $('#winCount').text(deviceCounts.Windows)
            $('#macCount').text(deviceCounts.Mac)
            $('#activeBrowsers').text(sum)
        } else {
            $('#filteredIphoneCount').text(deviceCounts.iPhone)
            $('#filteredAndroidCount').text(deviceCounts.Android)
            $('#filteredWinCount').text(deviceCounts.Windows)
            $('#filteredMacCount').text(deviceCounts.Mac)
        }
    }

    classifyDevices() {
        let devices = { iphone: [], android: [], windows: [], mac: [] };
    
        this.filteredList.forEach(item => {
            const userAgent = JSON.parse(item.personality).Device.userAgent;
    
            if (userAgent.includes("iPhone")) {
                devices.iphone.push(item.personality);
            } else if (userAgent.includes("Android")) {
                devices.android.push(item.personality);
            } else if (userAgent.includes("Win")) {
                devices.windows.push(item.personality);
            } else if (userAgent.includes("Mac")) {
                devices.mac.push(item.personality);
            }

            
        });
    
        return devices;
 

    }

    async updateStatusBots() {

        return new Promise(async resolve => {

            let fullData = [...this.personalities];
            let fileNames = fullData.map(value => value.fullname);
            let on = [];
            let off = [];

            // Use Promise.all() to wait for all AJAX requests to complete
            await Promise.all(fileNames.map(async (fName, index) => {
                try {
                    // Post the name to the isFilerunning endpoint to check if the fileName is currently running
                    const response = await $.ajax({
                        url: `http://localhost:3000/isRunning`,
                        method: "POST",
                        dataType: "json",
                        contentType: 'application/json',
                        data: JSON.stringify({ botName: fName }),
                    });

                    // Handle the response frotrm the server
                    if (response.status === 'running') {
                        on.push(fullData[index]);
                    } else {
                        off.push(fullData[index]);
                    }
                } catch (error) {
                    // Handle any errors that occur during the request
                    console.error('Error couldnt check if the bot file is running !:', error);
                }
            }));

            // Update statusBots after all requests are complete
            this.botStatus.runningBots = [...on];
            this.botStatus.offBots = [...off];

            resolve();

        });

    }

    async render(filtered) {

        return new Promise(async (resolve) => {


            await this.updateStatusBots();
            this.renderEngine.listBotTable(filtered);

            await this.renderEngine.renderPagination(filtered);
            this.countDevices(filtered)
            this.renderFilter();
            resolve();
        })
    }



}