import { imgTog } from './js/imgTog.js';

$(document).ready(function () {

    var apiKey = null;

    async function pop(msg) {
        // show a custom pop up denoting a challenege / Error encountered

        // update the pop ip title 
        $('#buildLogHeader').text(msg.title);

        // lets update the message 
        $('#buildLogMsg').html(msg.body);

        // pop up the notification 
        $('#buildLog').modal('show');

    }

    // Initiate the image Toggle for the active / inactive button #switch element
    let menuToggle = new imgTog("#menuSwitch", {
        "attr": {
            "src": "images/menu1.png"
        },
        "memo": "maximize menu",
        "remove-others-class": [{
            target: "#sidebar",
            val: "minMenu"
        }]

    });
    menuToggle.addConfig({
        "attr": {
            "src": "images/menu2.png"
        },
        "memo": "minimize menu",
        "add-others-class": [{
            target: "#sidebar",
            val: "minMenu"
        }]

    });
    $("#menuSwitch").click(function () {
        menuToggle.toggle();
    })
    // <--


    let login = false;

    (async function prepare() {

        apiKey = (await $.get("login/key.json"));

        if ((apiKey["apiKey"] == null) || (apiKey["apiKey"] == "") || (apiKey["apiKey"] == undefined)) {
            $('#viewer').load("component/login.html");
        } else {
            login = true
            $(".menu-btn").click(function () {

                //event.preventDefault(); // Prevent the default action

                if (login) {

                    window.location.href = "#" + $(this).attr('href');
                    window.location.reload();
                }

            })

            // load the hash url if it exists
            if (window.location.hash) {

                $("#loadingData").modal({
                    backdrop: 'static',
                    keyboard: false
                })

                let targetUrl = window.location.hash.slice(1);
                console.log(targetUrl);
                $('#viewer').load(targetUrl);
            }


        }


    })();




    $(".components li").click(function () {
        $(".menu-btn").removeClass("activeSideChild");
        $(".components li").removeClass("activeSide");
        $(this).addClass("activeSide");

    });

    $(".menu-btn").click(function () {
        $(".menu-btn").removeClass("activeSideChild");
        $(this).addClass("activeSideChild");

    });

})







