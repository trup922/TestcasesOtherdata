const path = require('path');
const { app, BrowserWindow } = require('electron');
const { exec } = require('child_process');

let win;



async function createWindow() {
  exec('node server.js')
  win = new BrowserWindow({
    title:"okecbot",
    width: 1300,
    height: 800,
    icon: __dirname + '/website/images/okecbot.png',
    webPreferences: {
      nodeIntegration: true
    }
  });

  // Load your dashboard
  win.loadURL("http://localhost:3000");
  
  // Optionally open DevTools.
   //win.webContents.openDevTools()
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

